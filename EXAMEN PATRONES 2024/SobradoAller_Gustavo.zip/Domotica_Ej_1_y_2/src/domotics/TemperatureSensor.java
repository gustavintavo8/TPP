package domotics;

public class TemperatureSensor extends Sensor {

	public TemperatureSensor(String name) {
		super(name);
	}

}
