package domotics;

public class Main {
	
	public static void main(String[] args) {
		// create client
		Client client1 = new Client();

		// add sensors to the hubs
		client1.configureCamAndMove();
		client1.configureTemp();

		// show the client hub(s) and sensors
		System.out.println(client1);	
	}	
}
