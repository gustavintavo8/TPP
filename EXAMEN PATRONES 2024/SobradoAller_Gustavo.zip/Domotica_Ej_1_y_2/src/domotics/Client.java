package domotics;

public class Client {

	// sensors
	private Sensor camSensor;
	private Sensor tempSensor;
	private Sensor moveSensor;
	// hubs
	private SmartHubSingleton hub1;
	private SmartHubSingleton hub2;


	public Client() {
		// create sensors
		this.camSensor = new CameraSensor("Cam01");
		this.tempSensor = new TemperatureSensor("Temp01");
		this.moveSensor = new MovementSensor("Move01");

		// create hubs
		this.hub1 = SmartHubSingleton.getInstancia();
		this.hub2 = SmartHubSingleton.getInstancia();
	}


	/**
	 * add camera and movement sensor to the hub
	 */
	public void configureCamAndMove() {
		hub1.addSensor(camSensor);
		hub1.addSensor(moveSensor);
	}

	/**
	 * add temperature sensor to the hub
	 */
	public void configureTemp() {
		hub2.addSensor(tempSensor);
	}



	@Override
	public String toString() {
		return String.format("Client \n\thub1=%s\n\thub2=%s]", hub1, hub2);
	}
}
