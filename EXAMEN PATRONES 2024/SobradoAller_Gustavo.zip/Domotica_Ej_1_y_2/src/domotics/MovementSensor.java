package domotics;

public class MovementSensor extends Sensor {

	public MovementSensor(String name) {
		super(name);
	}

}
