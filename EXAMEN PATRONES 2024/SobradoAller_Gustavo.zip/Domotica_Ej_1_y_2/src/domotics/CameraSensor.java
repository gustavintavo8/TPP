package domotics;

public class CameraSensor extends Sensor {

	public CameraSensor(String serial) {
		super(serial);
	}

}
