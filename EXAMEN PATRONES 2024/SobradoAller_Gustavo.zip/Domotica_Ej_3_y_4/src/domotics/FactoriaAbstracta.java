package domotics;

public interface FactoriaAbstracta {

	public CameraSensor creaCameraSensor();
	public SmartHub creaSmartHub();

}
