package domotics;

public class Factoria1000 implements FactoriaAbstracta{

	private String name;

	public Factoria1000(String n) {
		this.name = n;
	}

	@Override
	public CameraSensor creaCameraSensor() {
		return new CameraSensor1000(name);
	}

	@Override
	public SmartHub creaSmartHub() {
		return new SmartHub1000();
	}

}
