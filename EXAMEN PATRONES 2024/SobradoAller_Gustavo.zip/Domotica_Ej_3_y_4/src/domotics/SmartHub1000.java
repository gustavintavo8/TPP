package domotics;

public class SmartHub1000 extends SmartHub{
		
	public SmartHub1000() {
		
	}
}
