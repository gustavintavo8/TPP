package domotics;

public class Main {

	public static void main(String[] args) {
		Client client1 = new Client();
		Client client2 = new Client();
		
		// configuration with: standard series
		client1.configure("standard");
		
		//configuration with: 1000 series
		client2.configure("1000");
		
		// show clients
		System.out.println(client1);
		System.out.println(client2);
	}	

}
