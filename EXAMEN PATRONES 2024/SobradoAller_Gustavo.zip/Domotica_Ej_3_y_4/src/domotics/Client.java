package domotics;

public class Client {

	private FactoriaAbstracta laFactoria;

	// sensors
	private Sensor camera;
	// hub
	private SmartHub hub;


	public Client() {
		camera = null;
		hub = null;
		if(laFactoria.equals("1000")) {
			laFactoria = new Factoria1000("webcam01");
		}
		else if (laFactoria.equals("standard")) {
			laFactoria = new FactoriaBasico("webcam01");
		}
	}


	/**
	 * this method creates the appropriate sensor and hubs for the given series:
	 * @param serie - should be "standard" or "1000"
	 */
	public void configure(String serie) {
		if(serie.contentEquals("1000")) {
			laFactoria = new Factoria1000("webcam01");

		} else if(serie.contentEquals("standard")){
			laFactoria = new FactoriaBasico("webcam01");
		}

		// assign camera to the hub
		hub.addSensor(camera);

	}


	@Override
	public String toString() {
		return String.format("Client\n\thub=%s", hub);
	}

}
