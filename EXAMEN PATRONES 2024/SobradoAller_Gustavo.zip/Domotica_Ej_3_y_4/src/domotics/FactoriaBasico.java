package domotics;

public class FactoriaBasico implements FactoriaAbstracta{

	private String name;

	public FactoriaBasico(String n) {
		this.name = n;
	}

	@Override
	public CameraSensor creaCameraSensor() {
		return new CameraSensor(name);
	}

	@Override
	public SmartHub creaSmartHub() {
		return new SmartHub();
	}

}
