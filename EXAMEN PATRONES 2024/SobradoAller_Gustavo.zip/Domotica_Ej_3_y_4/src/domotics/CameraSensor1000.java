package domotics;

public class CameraSensor1000 extends CameraSensor {

	public CameraSensor1000(String name) {
		super(name);
	}

}
