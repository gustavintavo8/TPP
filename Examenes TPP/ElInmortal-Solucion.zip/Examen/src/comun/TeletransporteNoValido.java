package comun;

public class TeletransporteNoValido extends Exception {

	public TeletransporteNoValido() {
		// TODO Auto-generated constructor stub
	}

	public TeletransporteNoValido(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public TeletransporteNoValido(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public TeletransporteNoValido(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public TeletransporteNoValido(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
