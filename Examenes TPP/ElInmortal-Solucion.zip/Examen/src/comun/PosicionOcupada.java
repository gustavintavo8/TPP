package comun;

public class PosicionOcupada extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8436953864801996973L;

	public PosicionOcupada() {
		// TODO Auto-generated constructor stub
	}

	public PosicionOcupada(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PosicionOcupada(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PosicionOcupada(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PosicionOcupada(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
