package comun;

public class PotenciaNoValida extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3552909712530081427L;

	public PotenciaNoValida() {
		// TODO Auto-generated constructor stub
	}

	public PotenciaNoValida(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PotenciaNoValida(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PotenciaNoValida(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PotenciaNoValida(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
