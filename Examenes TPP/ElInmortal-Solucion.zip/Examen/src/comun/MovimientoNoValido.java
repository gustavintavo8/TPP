package comun;

public class MovimientoNoValido extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3865711215137831586L;

	public MovimientoNoValido() {
		// TODO Auto-generated constructor stub
		super();
	}

	public MovimientoNoValido(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MovimientoNoValido(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public MovimientoNoValido(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MovimientoNoValido(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
