package comun;



public interface IAvatar extends lib.DefaultService {
	// constantes configurables
	static final int NUMERO_JUGADORES = 2;
	static final int DIMENSION = 5;
	static final int VITALIDAD_INICIAL = 10;
	static final int MAX_TELETRANSPORTES=3;
	static final int MAXIMO = 5;
	static final int INICIAR_DESPLAZAMIENTO = 50;	// en milisegundos
	static final int PENALIZACION = 500;  			// en milisegundos
	
	void unirse(String alias, int potencia)
			throws JuegoIniciado, AliasDuplicado, PotenciaNoValida;
	
	boolean comenzar();
	
	void moverX(boolean b)
			throws MovimientoNoValido, PosicionOcupada;
	
	void moverY(boolean  b)
			throws MovimientoNoValido, PosicionOcupada;
	
	void mover2X(boolean b)
			throws MovimientoNoValido, PosicionOcupada;
	
	void mover2Y(boolean b)
			throws MovimientoNoValido, PosicionOcupada;
	
	void teletransporte() throws TeletransporteNoValido;
	
	Coordenadas posicion();
	
	int vida();
	
	void setPotencia(int potencia) throws PotenciaNoValida;
	
	boolean atacar(int fila, int columna);
	
	boolean juegoFinalizado();
}
