package comun;

public class JuegoIniciado extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2923371315213541044L;

	public JuegoIniciado() {
		// TODO Auto-generated constructor stub
	}

	public JuegoIniciado(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public JuegoIniciado(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public JuegoIniciado(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public JuegoIniciado(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
