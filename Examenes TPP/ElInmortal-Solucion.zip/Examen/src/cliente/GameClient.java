package cliente;


import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import comun.AliasDuplicado;
import comun.Coordenadas;
import comun.IAvatar;
import comun.JuegoIniciado;
import comun.MovimientoNoValido;
import comun.PosicionOcupada;
import comun.PotenciaNoValida;
import comun.TeletransporteNoValido;
import lib.ChannelException;
import lib.CommClient;
import lib.Menu;
import lib.ProtocolMessages;


public class GameClient {

	private static CommClient com = null; // canal de comunicaciÃ³n del cliente
	private static Menu m;			// interfaz
	
	private static List<String> lista= new LinkedList<String>();
	
	private static String alias = null;
	private static int potencia = 0;
	private static int vida = 0;
    private static int armadura = 0;
    private static Coordenadas pos = null;
    private static boolean muerto = false;
    private static boolean salir = false;
	
	public static void esperarJugadores() {
		ProtocolMessages msg = null;
		ProtocolMessages resp = null;
		boolean todos_unidos = false;

		System.out.println("Esperando que se unan el resto de jugadores...");
		
		while (!todos_unidos) {
			// Llamar remotamente a la operaciÃ³n del servidor
			// Crear el mensaje
			msg = new ProtocolMessages("comenzar");
			
			try {
				// Enviar Mensaje
				com.sendEvent(msg);
					
			    // Esperamos por la respuesta (la operaciÃ³n NO es oneway)
				resp = com.waitReply();
			
			    // Procesamos la respuesta y obtenemos el valor retornado por la operaciÃ³n
				todos_unidos = (boolean)com.processReply(resp);
			   
			} catch (Exception e) {
			}			
		}
	}
	public static boolean unirsePartida() {
		ProtocolMessages msg = null;
		ProtocolMessages resp = null;
		Scanner scan = new Scanner(System.in);

		// Le pido al usuario el alias que quiere ponerse
		if (alias == null) {
			System.out.print("Â¿QuÃ© alias quieres ponerte? ");
			alias = scan.nextLine();
		}
		
		// Le pido al usuario que potencia inicial quiere
		if (potencia == 0) {
			System.out.print("Â¿QuÃ© potencia inicial quieres? ");
			potencia = scan.nextInt();
			scan.nextLine();
		}
		
		System.out.println("Intentado unirse a la partida...");

		// Llamar remotamente a la operaciÃ³n del servidor
		// Crear el mensaje
		msg = new ProtocolMessages("unirse", alias, potencia);
		
		try {
			// Enviar Mensaje
			com.sendEvent(msg);
				
		    // Esperamos por la respuesta (la operaciÃ³n NO es oneway)
			resp = com.waitReply();
		
		    // Procesamos la respuesta y obtenemos el valor retornado por la operaciÃ³n
			com.processReply(resp);
						
			// Decirle algo al usuario
			System.out.println("Te has unido correctamente a la partida");
		   
		} catch (JuegoIniciado eji) {
			System.out.println(eji.getMessage());
			System.out.println("Saliendo del juego...");
			System.exit(-1);
		} catch (AliasDuplicado ead) {
			System.out.println(ead.getMessage());
			alias = null;
			return false;
		} catch (PotenciaNoValida epnv) {
			System.out.println(epnv.getMessage());
			potencia = 0;
			return false;
		} catch (Exception e) {
			System.err.println("Â¡Error general!");
			potencia = 0;
			alias = null;
			return false;
		}
		
		// Se ha unido correctamente
		armadura = IAvatar.MAXIMO - potencia;
		return true;
	}
	
	public static int vidaAvatar() {
		ProtocolMessages msg = null;
		ProtocolMessages resp = null;
		int vida = 0;
		 
		// Llamar remotamente a la operaciÃ³n del servidor
		// Crear el mensaje
		msg = new ProtocolMessages("vida");
		
		try {
		    // Enviar Mensaje
			com.sendEvent(msg);
			
			// Esperar por la respuesta
			resp = com.waitReply();
		
		   // Procesamos la respuesta y obtenemos el valor retornado por la operaciÃ³n
			vida = (int)com.processReply(resp);			
			
		} catch (Exception e) {
			System.err.println("Â¡Error! No se ha podido obtener la vida del avatar.");
		}
		
		return vida;		
	}
	
	public static Coordenadas posicionTablero() {
		ProtocolMessages msg = null;
		ProtocolMessages resp = null;
		Coordenadas coord = null;
		 
		// Llamar remotamente a la operaciÃ³n del servidor
		// Crear el mensaje
		msg = new ProtocolMessages("posicion");
		
		try {
		    // Enviar Mensaje
			com.sendEvent(msg);
			
			// Esperar por la respuesta
			resp = com.waitReply();
		
		   // Procesamos la respuesta y obtenemos el valor retornado por la operaciÃ³n
			coord = (Coordenadas)com.processReply(resp);			
			
		} catch (Exception e) {
			System.err.println("Â¡Error! No se ha podido obtener la posiciÃ³n del tablero.");
		}
		
		return coord;
	}
	
	public static boolean juegoFinalizado() {
		ProtocolMessages msg = null;
		ProtocolMessages resp = null;
		boolean fin = false;;
		 
		// Llamar remotamente a la operaciÃ³n del servidor
		// Crear el mensaje
		msg = new ProtocolMessages("juegoFinalizado");
		
		try {
		    // Enviar Mensaje
			com.sendEvent(msg);
			
			// Esperar por la respuesta
			resp = com.waitReply();
		
		   // Procesamos la respuesta y obtenemos el valor retornado por la operaciÃ³n
			fin = (boolean)com.processReply(resp);			
			
		} catch (Exception e) {
			System.err.println("Â¡Error! No se ha podido saber si el juego ha finalizado.");
		}
		
		return fin;
	}
	
	public static void moverHorizontal(int n, boolean b)  {
		ProtocolMessages msg = null;
		ProtocolMessages resp = null;

		// Llamar remotamente a la operaciÃ³n del servidor
		// Crear el mensaje
		if (n == 1)
			msg = new ProtocolMessages("moverY", b);
		else
			msg = new ProtocolMessages("mover2Y", b);
		
		try {
			// Enviar Mensaje
			com.sendEvent(msg);
				
		    // Esperamos por la respuesta (la operaciÃ³n NO es oneway)
			resp = com.waitReply();
		
		    // Procesamos la respuesta y obtenemos el valor retornado por la operaciÃ³n
			com.processReply(resp);
						
			// Decirle algo al usuario
			System.out.println("Movimiento realizado");			
		   
		} catch (MovimientoNoValido env) {
			System.out.println(env.getMessage());
			return;
		} catch (PosicionOcupada epo) {
			System.out.println(epo.getMessage());
			return;
		} catch (Exception e) {
			System.err.println("Â¡Error! No he podido hacer el movimiento.");
			return;
		}
	}

	public static void moverVertical(int n, boolean b)  {
		ProtocolMessages msg = null;
		ProtocolMessages resp = null;

		// Llamar remotamente a la operaciÃ³n del servidor
		// Crear el mensaje
		if (n == 1)
			msg = new ProtocolMessages("moverX", b);
		else
			msg = new ProtocolMessages("mover2X", b);
		
		try {
			// Enviar Mensaje
			com.sendEvent(msg);
				
		    // Esperamos por la respuesta (la operaciÃ³n NO es oneway)
			resp = com.waitReply();
		
		    // Procesamos la respuesta y obtenemos el valor retornado por la operaciÃ³n
			com.processReply(resp);
						
			// Decirle algo al usuario
			System.out.println("Movimiento realizado");			
		   
		} catch (MovimientoNoValido env) {
			System.out.println(env.getMessage());
			return;
		} catch (PosicionOcupada epo) {
			System.out.println(epo.getMessage());
			return;
		} catch (Exception e) {
			System.err.println("Â¡Error! No he podido hacer el movimiento.");
		}
	}

	public static void atacar() {
		ProtocolMessages msg = null;
		ProtocolMessages resp = null;
		Scanner scan = new Scanner(System.in);
		int fila, col;
		boolean acierto = false;
		
		// Pregunta al usuario por la posiciÃ³n a atacar
		System.out.print("Â¿Fila a atacar? [1-" + IAvatar.DIMENSION + "] ");
		fila = scan.nextInt();
		scan.nextLine();
		System.out.print("Â¿Columna a atacar? [1-" + IAvatar.DIMENSION + "] ");
		col = scan.nextInt();
		scan.nextLine();

		// Llamar remotamente a la operaciÃ³n del servidor
		// Crear el mensaje
		msg = new ProtocolMessages("atacar", fila-1, col-1);
		
		try {
			// Enviar Mensaje
			com.sendEvent(msg);
				
		    // Esperamos por la respuesta (la operaciÃ³n NO es oneway)
			resp = com.waitReply();
		
		    // Procesamos la respuesta y obtenemos el valor retornado por la operaciÃ³n
			acierto = (boolean)com.processReply(resp);
						
			// Decirle algo al usuario
			if (acierto) {
				System.out.println("Â¡Has atacado a un avatar!");
			}
			else {
				System.out.println("Â¡Ataque fallido!");
			}		   
  		} catch (Exception e) {
			System.err.println("Â¡Error! No he podido realizar el ataque.");
		}		
	}
	
	public static void teletransportarse() {
		ProtocolMessages msg;
		ProtocolMessages respuesta;
		
		msg = new ProtocolMessages("teletransportarse");
		try {
			com.sendEvent(msg);

			// Esperamos por la respuesta (la operaciÃ³n NO es oneway)
			respuesta = com.waitReply();

			// Procesamos la respuesta y obtenemos el valor retornado por la operaciÃ³n
			com.processReply(respuesta);

		} catch (TeletransporteNoValido e) {
			System.err.println("¡Error! No he podido realizar la teletransportación, has alcanzado el número máximo de teletransportaciones.");
			return;
		}catch(Exception e) {
			e.printStackTrace();
			return;
		}
		
		
		System.out.println("Se ha realizado el teletransporte de forma exitosa.");
	}
	
	//EJERCICIO3	
	@SuppressWarnings({ "unchecked", "unlikely-arg-type" })
	public static void avataresVivos() {

		try {
			ProtocolMessages msg;
			ProtocolMessages respuesta;
			List<String> anterior=new LinkedList<String>(lista);
			msg=new ProtocolMessages("verAlias");
			
			com.sendEvent(msg);
			respuesta=com.waitReply();
			List<String> l = (List<String>)com.processReply(respuesta);
			lista=new LinkedList<String>(l);

			for(String s : l) {
				if(anterior.contains(s))
					anterior.remove(s);
			}

			if(!anterior.isEmpty())
				for(String s: anterior) {
					System.out.println("El jugador " + s + " ¡HA MUERTO! ¡SOLO PUEDE QUEDAR UNO!\n");
				}

			System.out.println("Los avatares que están vivos son: ");
			for(String s : l) {
				System.out.println(s);
			}
		}catch(Exception e ) {
			e.printStackTrace();
		}
	}
	
	public static void cambiarPotencia() {
		ProtocolMessages msg = null;
		ProtocolMessages resp = null;
		Scanner scan = new Scanner(System.in);
		int new_potencia;
		
		// Pregunta al usuario por la nueva potencia
		System.out.print("Â¿Nueva potencia? ");
		new_potencia = scan.nextInt();
		scan.nextLine();

		// Llamar remotamente a la operaciÃ³n del servidor
		// Crear el mensaje
		msg = new ProtocolMessages("setPotencia", new_potencia);
		
		try {
			// Enviar Mensaje
			com.sendEvent(msg);
				
		    // Esperamos por la respuesta (la operaciÃ³n NO es oneway)
			resp = com.waitReply();
		
		    // Procesamos la respuesta y obtenemos el valor retornado por la operaciÃ³n
			com.processReply(resp);
						
			// Decirle algo al usuario
			System.out.println("Potencia cambiada correctamente.");
			potencia = new_potencia;
			armadura = IAvatar.MAXIMO - potencia;
  		} catch (PotenciaNoValida epnv) {
			System.out.println(epnv.getMessage());
  		} catch (Exception e) {
			System.err.println("Â¡Error! No he podido cambiar la potencia.");
		}		
	}
	
	public static Menu interfazCliente()  {
    	Menu m = new Menu("Juego del inmortal", "Â¿OpciÃ³n? ");
    	
    	
    	
    	
    	m.add("Mover uno a la izquierda", 
    			() -> moverHorizontal(1, false));
    	m.add("Mover uno a la derecha", 
    			() -> moverHorizontal(1, true));
    	m.add("Mover uno arriba", 
    			() -> moverVertical(1, false));
    	m.add("Mover uno abajo", 
    			() -> moverVertical(1, true));
    	m.add("Mover dos a la izquierda", 
    			() -> moverHorizontal(2, false));
    	m.add("Mover dos a la derecha", 
    			() -> moverHorizontal(2, true));
    	m.add("Mover dos arriba", 
    			() -> moverVertical(2, false));
    	m.add("Teletransportarse",()->teletransportarse());
    	m.add("Mover dos abajo", 
    			() -> moverVertical(2, true));
    	m.add("Atacar", 
    			() -> atacar());
    	m.add("Cambiar potencia", 
    			() -> cambiarPotencia());
    	return m;
	}	
	
    public static void main(String[] args)  {
    	// crear el canal de comunicaciÃ³n y establecer la
    	// conexiÃ³n con el servicio por defecto en localhost
		try {
			com = new CommClient();
		} catch (IOException | ChannelException e) {
			// Error no recuperable
			System.err.println("Â¡Â¡Error grave!! No puedo establecer comunicaciÃ³n con el servidor.");
			System.exit(-1);
		}

		// activa el registro de mensajes del cliente
		//com.activateMessageLog();  // opcional

		// Pregunta los datos de alias y potencia hasta que sean vÃ¡lidos
		while (!unirsePartida());
		
		// Espera a que se unan el resto de jugadores
		esperarJugadores();
		
		// La partida comienza
		System.out.println(String.format("Â¡Â¡La partida va a comenzar en 5 segundos!!"));
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// Error recuperable
		}
		
		// crear la interfaz
		m = interfazCliente();

		// lanzar eventos mediante la interfaz
		try {
			do {
				// InformaciÃ³n del avatar
				pos = posicionTablero();
				vida = vidaAvatar();
				muerto = vida == 0;
				if (!muerto)  {
					System.out.println(String.format("\nAvatar: %s     Fila: %d  Col: %d      Campo de batalla de %dX%d",
													 alias, pos.abscisa()+1, pos.ordenada()+1, IAvatar.DIMENSION, IAvatar.DIMENSION));
					System.out.println(String.format("Vida: %d     Potencia: %d      Armadura: %d\n", vida, potencia, armadura));
				}
				avataresVivos();
				
				salir = !m.runSelection();
			} while (!salir && !muerto && !juegoFinalizado());
		} catch (Exception e) {
			// Error NO recuperable
			System.err.println("Â¡Â¡Error grave!! Fallaron las comunicaciones con el servidor.");
			System.exit(-1);
		}
		
		if (muerto) {
			// Hemos salido del menÃº porque el jugador ha muerto. Se lo indicamos
			System.out.println(String.format("\nAvatar: %s   Â¡Â¡ESTÃ�S MUERTO!!\n", alias));			
		}
		
		if (!salir) {
			// Si el jugador no ha querido salir voluntariamente se le deja esperando a que termine la partida
			System.out.println("Esperando a que finalice la partida...");		
			while (!juegoFinalizado());
			// El juego ha finalizado
			System.out.println("\nÂ¡Â¡EL JUEGO HA FINALIZADO!!\n");
			// Comprobamos si el jugado ganÃ³ o no la partida
			if (vidaAvatar() > 0) {
				System.out.println(String.format("\nAvatar: %s  Â¡Â¡HAS GANADO LA PARTIDA!!\n", alias));							
			}
		}


		// cierra la interfaz si es necesario
		m.close();

		// cierra el canal de comunicaciÃ³n y
		// desconecta el cliente
		com.disconnect();    	
    } // main


} // class GameClient
