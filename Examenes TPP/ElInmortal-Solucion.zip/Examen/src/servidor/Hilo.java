package servidor;

import java.io.IOException;

import lib.ChannelException;
import lib.CommServer;
import lib.ProtocolMessages;

public class Hilo implements Runnable {
	// Area de datos
	private int idClient;
	private CommServer com;
	private AvatarOOS oos;
	
	public Hilo(int id, CommServer c, AvatarOOS o) {
		this.idClient = id;
		this.com = c;
		this.oos = o;
	}

	@Override
	public void run() {
		ProtocolMessages event = null;
		ProtocolMessages resp = null;
		
		try {
			while (!this.com.closed(this.idClient)) {
				try {
					// Esperar por un evento 
					event = this.com.waitEvent(this.idClient);
	
					// Procesar evento
					resp = this.com.processEvent(this.idClient, this.oos, event);
					
					// Si procede, enviar respuesta
					if (resp != null) {
						this.com.sendReply(this.idClient, resp);
					}
					
				} catch (ClassNotFoundException e) {
					// Error recuperable
					System.err.println("¡Error en el mensaje del cliente " + this.idClient + "!");
				}
			}
		} catch (IOException | ChannelException e) {
			// Error NO recuperable
			System.err.println("¡Error en el canal de comunicaciones del cliente " + this.idClient + "!");
			System.err.println("Se finaliza la conexión con dicho cliente");
		}
	
		// El cliente se desconectó. Cierra el objeto servicio
		this.oos.close();
	}

}
