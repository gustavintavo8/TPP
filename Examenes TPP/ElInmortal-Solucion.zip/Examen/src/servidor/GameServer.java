package servidor;

import java.io.IOException;

import lib.CommServer;

public class GameServer {
	
	private static void registrarOperaciones(CommServer com) {
		com.addAction("unirse", (o, x) -> ((AvatarOOS)o).unirse((String)x[0], (int)x[1]));
		com.addFunction("comenzar", (o, x) -> ((AvatarOOS)o).comenzar());
		com.addAction("moverX", (o, x) -> ((AvatarOOS)o).moverX((boolean)x[0]));
		com.addAction("moverY", (o, x) -> ((AvatarOOS)o).moverY((boolean)x[0]));
		com.addAction("mover2X", (o, x) -> ((AvatarOOS)o).mover2X((boolean)x[0]));
		com.addAction("mover2Y", (o, x) -> ((AvatarOOS)o).mover2Y((boolean)x[0]));
		com.addFunction("posicion", (o, x) -> ((AvatarOOS)o).posicion());
		com.addFunction("vida", (o, x) -> ((AvatarOOS)o).vida());
		com.addAction("setPotencia", (o, x) -> ((AvatarOOS)o).setPotencia((int)x[0]));
		com.addFunction("atacar", (o, x) -> ((AvatarOOS)o).atacar((int)x[0], (int)x[1]));
		com.addFunction("juegoFinalizado", (o, x) -> ((AvatarOOS)o).juegoFinalizado());
		
		
		com.addAction("teletransportarse", (o,x)->((AvatarOOS)o).teletransporte());
		
		com.addFunction("verAlias",(o,x)-> ((AvatarOOS)o).aliasJugadoresVivos());
	}

	public static void main(String[] args) {
		CommServer com = null;
		AvatarOOS player = null;
		int idClient;
		
		// Crear el canal de comunicaciones
		try {
			com = new CommServer();
		} catch (IOException e) {
			// Error NO recuperable
			System.err.println("¡No se podido crear el canal de comunicaciones!");
			System.err.println("El servidor va a finalizar su ejecución");
			System.exit(-1);
		}
		
		// Activar la traza
		//com.activateMessageLog();
		
		// Registrar las operaciones
		registrarOperaciones(com);
		
		while (true) {
			// Esperamos a que se conecte un cliente
			try {
				// Esperar por la conexión de un cliente
				idClient = com.waitForClient();
				
				// Crear una instancia de la clase AvatarOOS
				player = new AvatarOOS(idClient);
				
				// Crear y lanzar un hilo
				new Thread(new Hilo(idClient, com, player)).start();
			} catch (Exception e) {
				// Error recuperable
				System.err.println("¡Falló la conexión con un cliente!");
				System.err.println("El servidor continuará su ejecución");
			}
		}
	}

}
