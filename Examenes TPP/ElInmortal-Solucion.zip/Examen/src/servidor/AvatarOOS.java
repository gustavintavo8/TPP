package servidor;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Semaphore;

import comun.AliasDuplicado;
import comun.Coordenadas;
import comun.IAvatar;
import comun.JuegoIniciado;
import comun.MovimientoNoValido;
import comun.PosicionOcupada;
import comun.PotenciaNoValida;
import comun.TeletransporteNoValido;

public class AvatarOOS implements IAvatar {
	static final Avatar avatarNulo = null;
	// 1. InformaciÃ³n Compartida
	// Un tablero de DIMENSIONxDIMENSION de tipo Avatar
	private static Avatar [][] campoBatalla = null;
	// Lista de avatares muertos
	private static List<Avatar> avataresMuertos = new LinkedList<Avatar>();
	// Lista de avatares vivos
	private static List<Avatar> avataresVivos = new LinkedList<Avatar>();
	// Numero de jugadores conectados
	private static int jugadoresConectados = 0;
	// Numero de jugadores unidos
	private static int jugadoresUnidos = 0;
	
	// SemÃ¡foros de exclusiÃ³n mutua
	private static Semaphore [][] mutex_tablero = null;
	private static Semaphore mutex_muertos = new Semaphore(1, true);
	private static Semaphore mutex_vivos = new Semaphore(1, true);
	private static Semaphore mutex_conectados = new Semaphore(1, true);
	private static Semaphore mutex_unidos = new Semaphore(1, true);

	// InformciÃ³n NO Compartida
	int estado;
	int id_Cliente;
	Avatar jugador = null;

	// Clase Avatar (datos del jugador), solo accesible por la clase servicio AvatarOOS
	private static class Avatar {
		// informaciÃ³n del avatar
		String alias;
		int vitalidad;
		int potencia;
		int teletransportes;
		// posiciÃ³n en el campo de batalla
		Coordenadas pos;
		// propietario del avatar
		int idCliente;
		boolean fin;

		// Constructor		
		Avatar(int idCliente, String alias, int potencia) {
			this.alias = alias;
			this.vitalidad = VITALIDAD_INICIAL;
			this.teletransportes=MAX_TELETRANSPORTES;
			this.potencia = potencia;
			this.idCliente = idCliente;
			// posicionamiento al azar en un espacio
			// libre del campo de batalla (con avatar nulo)
			Random r = new Random();
			do {
				this.pos = new Coordenadas(r.nextInt(DIMENSION), r.nextInt(DIMENSION));
				try {
					mutex_tablero[this.pos.abscisa()][this.pos.ordenada()].acquire();
				} catch (InterruptedException e) {
					// Error no recuperable
					System.err.println("Cliente " + idCliente + ": No se ha podido adquirir el tablero en exclusiva");
					System.exit(-1);
				}
				fin = campoBatalla[this.pos.abscisa()][this.pos.ordenada()] == avatarNulo;
				if (!fin) {
					mutex_tablero[this.pos.abscisa()][this.pos.ordenada()].release();
				}
			} while (!fin);

			// Inicializar la posiciÃ³n (fila, columna) del campo de batalla con el avatar (objeto this)
			campoBatalla[this.pos.abscisa()][this.pos.ordenada()] = this;			
			mutex_tablero[this.pos.abscisa()][this.pos.ordenada()].release();
		}
	}

	// Constructor de la clase servicio
	public AvatarOOS(int idc) {
		int i, j;

		// Creo el tablero, UNA ÃšNICA VEZ (el primer cliente que se conecta) e inicializo 
		// todas las casillas a la casilla vacÃ­a
		if (campoBatalla == null) {
			campoBatalla = new Avatar[DIMENSION][DIMENSION];
			for (i=0; i<DIMENSION; i++) {
				for (j=0; j<DIMENSION; j++) {
					campoBatalla[i][j] = avatarNulo;
				}
			}
		}
		
		// Inicializa los semÃ¡foros del tablero (uno por casilla) UNA ÃšNICA VEZ (el primer cliente que se conecta)
		if (mutex_tablero == null) {
			mutex_tablero = new Semaphore[DIMENSION][DIMENSION];
			for (i=0; i<DIMENSION; i++) {
				for (j=0; j<DIMENSION; j++) {
					mutex_tablero[i][j] = new Semaphore(1, true);
				}
			}			
		}
		// Hay un jugador conectado mÃ¡s
		try {
			mutex_conectados.acquire();
		} catch (InterruptedException e) {
			// Error no recuperable
			System.err.println("Cliente " + idc + ": No se ha podido adquirir jugadoresConectados en exclusiva");
			System.exit(-1);
		}
		jugadoresConectados++;
		mutex_conectados.release();
		
		// Estado inicial del cliente 
		this.estado = -10;
		
		// Almacenamos el id del cliente
		this.id_Cliente = idc;
	}
	
	@Override
	public void unirse(String alias, int potencia) throws JuegoIniciado, AliasDuplicado, PotenciaNoValida {
		// Comprueba que se pueda llamar a la operaciÃ³n
		if (this.estado != -10) return;
		
		// Comprueba que no se hayan ya unido todos los jugadores (Juego iniciado)
		try {
			mutex_unidos.acquire();
		} catch (InterruptedException e) {
			// Error no recuperable
			System.err.println("Cliente " + this.id_Cliente + ": No se ha podido adquirir jugadoresUnidos en exclusiva");
			System.exit(-1);
		}
		if (jugadoresUnidos == IAvatar.NUMERO_JUGADORES) {
			mutex_unidos.release();
			throw new JuegoIniciado("No puedes unirte, ya se ha alcanzado el mÃ¡ximo de jugadores.");
		}
		mutex_unidos.release();
		
		// Comprueba que no exista ya el alias
		try {
			mutex_vivos.acquire();
		} catch (InterruptedException e) {
			// Error no recuperable
			System.err.println("Cliente " + this.id_Cliente + ": No se ha podido adquirir la lista de avatares vivos en exclusiva");
			System.exit(-1);
		}
		for (Avatar av : avataresVivos) {
			if (av.alias.equals(alias))  {
				mutex_vivos.release();
				throw new AliasDuplicado("No puede ponerte ese alias, alguien lo estÃ¡ usando.");
			}
		}
		mutex_vivos.release();
		
		// Comprueba que la potencia sea vÃ¡lida
		if (potencia >= IAvatar.MAXIMO || potencia <= 0) {
			throw new PotenciaNoValida(String.format("No puedes ponerte esa potencia. Rango de potencia vÃ¡lida [1, %d]", IAvatar.MAXIMO - 1));
		}
		
		// Todo es correcto. Crea el avatar
		this.jugador = new Avatar(this.id_Cliente, alias, potencia);
		
		// Un jugador unido mÃ¡s
		try {
			mutex_unidos.acquire();
		} catch (InterruptedException e) {
			// Error no recuperable
			System.err.println("Cliente " + this.id_Cliente + ": No se ha podido adquirir jugadoresUnidos en exclusiva");
			System.exit(-1);
		}
		jugadoresUnidos++;
		mutex_unidos.release();
		
		// El avatar estÃ¡ vivo
		try {
			mutex_vivos.acquire();
		} catch (InterruptedException e) {
			// Error no recuperable
			System.err.println("Cliente " + this.id_Cliente + ": No se ha podido adquirir la lista de avatares vivos en exclusiva");
			System.exit(-1);
		}
		avataresVivos.add(this.jugador);
		mutex_vivos.release();
		
		// Se actualiza el estado de este jugador
		this.estado = -1;		
	}

	@Override
	public boolean comenzar() {
		// Comprueba que se pueda llamar a la operaciÃ³n
		if (this.estado != -1) return false;
		
		// Comprueba si la partida puede comenzar.
		// La partida comienza cuando se han unido todos los jugadores
		try {
			mutex_unidos.acquire();
		} catch (InterruptedException e) {
			// Error no recuperable
			System.err.println("Cliente " + this.id_Cliente + ": No se ha podido adquirir jugadoresUnidos en exclusiva");
			System.exit(-1);
		}
		if (jugadoresUnidos == IAvatar.NUMERO_JUGADORES) {
			mutex_unidos.release();
			// Se pasa al estado 0
			this.estado = 0;
			return true;
		}
		mutex_unidos.release();

		// No se han unido todos lo jugadores
		return false;
	}

	@Override
	public void moverX(boolean b) throws MovimientoNoValido, PosicionOcupada {
		// Declarar variable local para nueva posiciÃ³n
		Coordenadas new_pos;
		
		// Comprobar que la partida haya comenzado
		if (this.estado < 0) {
			throw new MovimientoNoValido("No puedes moverte, la partida no ha comenzado o no te has unido.");
		}
		
		// Comproba si el jugador estÃ¡ vivo
		if (this.estado == 100) {
			throw new MovimientoNoValido("No puedes moverte. Â¡Â¡ESTÃ�S MUERTO!!");
		}
		
		// Comprobar las restricciones de movimiento
		if (this.estado == 3) {
			throw new MovimientoNoValido("No puedes hacer ya este tipo de movimiento.");
		}

		// Comprobar si el avatar ha sido asesinado
		if (this.jugador.vitalidad == 0) {
			// Acaban de matar a este avatar. Pasamos al estado 100 y salimos
			this.estado = 100;
			throw new MovimientoNoValido("No puedes moverte. Â¡Â¡TE ACABAN DE ASESINAR!!");
		}
		
		// Asignar nueva posiciÃ³n a la variable local
		if (b) {
			// Moverse uno a la derecha
			new_pos = new Coordenadas(this.jugador.pos.abscisa()+1,this.jugador.pos.ordenada());
		}
		else {
			// Moverse uno a la izquierda
			new_pos = new Coordenadas(this.jugador.pos.abscisa()-1,this.jugador.pos.ordenada());
		}
		
		// Mover al avatar
		this.moverAvatar(new_pos);
				
		// Comprobar si paso a un estado nuevo
		if (this.estado == 0 || this.estado == 2 || this.estado == 4)
			this.estado = 1;
		else
			this.estado = 3;	
	}

	@Override
	public void moverY(boolean b) throws MovimientoNoValido, PosicionOcupada {
		// Declarar variable local para nueva posiciÃ³n
		Coordenadas new_pos;
		
		// Comprobar que la partida haya comenzado
		if (this.estado < 0) {
			throw new MovimientoNoValido("No puedes moverte, la partida no ha comenzado o no te has unido.");
		}
		
		// Comproba si el jugador estÃ¡ vivo
		if (this.estado == 100) {
			throw new MovimientoNoValido("No puedes moverte. Â¡Â¡ESTÃ�S MUERTO!!");
		}
		
		// Comprobar las restricciones de movimiento
		if (this.estado == 4) {
			throw new MovimientoNoValido("No puedes hacer ya este tipo de movimiento.");
		}

		// Comprobar si el avatar ha sido asesinado
		if (this.jugador.vitalidad == 0) {
			// Acaban de matar a este avatar. Pasamos al estado 100 y salimos
			this.estado = 100;
			throw new MovimientoNoValido("No puedes moverte. Â¡Â¡TE ACABAN DE ASESINAR!!");
		}
				
		// Asignar nueva posiciÃ³n a la variable local
		if (b) {
			// Moverse uno abajo
			new_pos = new Coordenadas(this.jugador.pos.abscisa(),this.jugador.pos.ordenada()+1);
		}
		else {
			// Moverse uno arriba
			new_pos = new Coordenadas(this.jugador.pos.abscisa(),this.jugador.pos.ordenada()-1);
		}
		
		// Mover al avatar
		this.moverAvatar(new_pos);
						
		// Comprobar si paso a un estado nuevo
		if (this.estado == 0 || this.estado == 1 || this.estado == 3)
			this.estado = 2;
		else
			this.estado = 4;	
	}

	@Override
	public void mover2X(boolean b) throws MovimientoNoValido, PosicionOcupada {
		// Declarar variable local para nueva posiciÃ³n
		Coordenadas new_pos;
		
		// Comprobar que la partida haya comenzado
		if (this.estado < 0) {
			throw new MovimientoNoValido("No puedes moverte, la partida no ha comenzado o no te has unido.");
		}
		
		// Comproba si el jugador estÃ¡ vivo
		if (this.estado == 100) {
			throw new MovimientoNoValido("No puedes moverte. Â¡Â¡ESTÃ�S MUERTO!!");
		}
		
		// Comprobar las restricciones de movimiento
		if (this.estado == 0 || this.estado == 1 || this.estado == 3) {
			throw new MovimientoNoValido("No puedes hacer ya este tipo de movimiento.");
		}

		// Comprobar si el avatar ha sido asesinado
		if (this.jugador.vitalidad == 0) {
			// Acaban de matar a este avatar. Pasamos al estado 100 y salimos
			this.estado = 100;
			throw new MovimientoNoValido("No puedes moverte. Â¡Â¡TE ACABAN DE ASESINAR!!");
		}
				
		// Asignar nueva posiciÃ³n a la variable local
		if (b) {
			// Moverse dos a la derecha
			new_pos = new Coordenadas(this.jugador.pos.abscisa()+2,this.jugador.pos.ordenada());
		}
		else {
			// Moverse dos a la izquierda
			new_pos = new Coordenadas(this.jugador.pos.abscisa()-2,this.jugador.pos.ordenada());
		}
		
		// Mover al avatar
		this.moverAvatar(new_pos);
						
		// Comprobar si paso a un estado nuevo
		this.estado = 3;	
	}

	@Override
	public void mover2Y(boolean b) throws MovimientoNoValido, PosicionOcupada {
		// Declarar variable local para nueva posiciÃ³n
		Coordenadas new_pos;
		
		// Comprobar que la partida haya comenzado
		if (this.estado < 0) {
			throw new MovimientoNoValido("No puedes moverte, la partida no ha comenzado o no te has unido.");
		}
		
		// Comproba si el jugador estÃ¡ vivo
		if (this.estado == 100) {
			throw new MovimientoNoValido("No puedes moverte. Â¡Â¡ESTÃ�S MUERTO!!");
		}
		
		// Comprobar las restricciones de movimiento
		if (this.estado == 0 || this.estado == 2 || this.estado == 4) {
			throw new MovimientoNoValido("No puedes hacer ya este tipo de movimiento.");
		}

		// Comprobar si el avatar ha sido asesinado
		if (this.jugador.vitalidad == 0) {
			// Acaban de matar a este avatar. Pasamos al estado 100 y salimos
			this.estado = 100;
			throw new MovimientoNoValido("No puedes moverte. Â¡Â¡TE ACABAN DE ASESINAR!!");
		}
		
		// Asignar nueva posiciÃ³n a la variable local
		if (b) {
			// Moverse dos abajo
			new_pos = new Coordenadas(this.jugador.pos.abscisa(),this.jugador.pos.ordenada()+2);
		}
		else {
			// Moverse dos arriba
			new_pos = new Coordenadas(this.jugador.pos.abscisa(),this.jugador.pos.ordenada()-2);
		}
		
		// Mover al avatar
		this.moverAvatar(new_pos);
						
		// Comprobar si paso a un estado nuevo
		this.estado = 4;	
	}

	@Override
	public Coordenadas posicion() {
		// Comprobar si se puede llamar a esta operaciÃ³n
		if (this.estado < 0 || this.estado == 100)
			return null;

		// Comprobar si el avatar ha sido asesinado
		if (this.jugador.vitalidad == 0) {
			// Acaban de matar a este avatar. Pasamos al estado 100 y salimos
			this.estado = 100;
			return null;
		}
				
		return this.jugador.pos;
	}


	@Override
	public int vida() {
		// Comprueba si tiene vida
		if (this.estado == -10 || this.estado == 100) {
			return 0;
		}

		// Comprobar si el avatar ha sido asesinado
		if (this.jugador.vitalidad == 0) {
			// Acaban de matar a este avatar. Pasamos al estado 100
			this.estado = 100;
		}
				
		return this.jugador.vitalidad;
	}

	@Override
	public void setPotencia(int potencia) throws PotenciaNoValida {
		// Comprueba si puede ponerse una nueva potencia
		if (this.estado < 0 || this.estado == 100) {
			return;
		}
		
		// Comprobar si el avatar ha sido asesinado
		if (this.jugador.vitalidad == 0) {
			// Acaban de matar a este avatar. Pasamos al estado 100 y salimos
			this.estado = 100;
			return;
		}
				
		// Comprueba que la potencia sea vÃ¡lida
		if (potencia >= IAvatar.MAXIMO || potencia < 1) {
			throw new PotenciaNoValida(String.format("No puedes ponerte esa potencia. Rango de potencia vÃ¡lida [1, %d]", IAvatar.MAXIMO - 1));
		}
		
		// Todo correcto, Aplicamos la penalizaciÃ³n
		if (this.jugador.potencia < potencia) {
			// Aumenta la potencia. Primero se cambia la potencia y luego se panaliza
			this.jugador.potencia = potencia;
			try {
				Thread.sleep(IAvatar.PENALIZACION);
			} catch (InterruptedException e) {
				// Error recuperable
				System.err.println("Cliente " + this.id_Cliente + ": No se ha podido aplicar penalizaciÃ³n por cambio de potencia al avatar");			
			}
		}
		else {
			// Se reduce la potencia. Primero se penaliza y luego se cambia la potencia
			try {
				Thread.sleep(IAvatar.PENALIZACION);
			} catch (InterruptedException e) {
				// Error recuperable
				System.err.println("Cliente " + this.id_Cliente + ": No se ha podido aplicar penalizaciÃ³n por cambio de potencia al avatar");			
			}
			this.jugador.potencia = potencia;
		}
	}

	@Override
	public boolean atacar(int fila, int columna) {		
		Coordenadas pos;
		Avatar atacado;
		int armadura;
		
		// Comprueba que pueda atacar
		if (this.estado < 0 || this.estado == 100) {
			return false;
		}
		
		// Comprobar si el avatar ha sido asesinado
		if (this.jugador.vitalidad == 0) {
			// Acaban de matar a este avatar. Pasamos al estado 100 y salimos
			this.estado = 100;
			return false;
		}
				
		// Comprueba que las coordenadas sean correctas
		pos = new Coordenadas(fila, columna);
		if (this.desbordamiento(pos)) {
			return false;
		}
		
		// Comprueba que efectivamente haya un avatar en esa casilla
		try {
			mutex_tablero[pos.abscisa()][pos.ordenada()].acquire();
		} catch (InterruptedException e) {
			// Error no recuperable
			System.err.println("Cliente " + this.id_Cliente + ": No se ha podido adquirir el tablero en exclusiva");
			System.exit(-1);
		}
		atacado = campoBatalla[pos.abscisa()][pos.ordenada()];
		if (atacado != avatarNulo) {
			// Ataque certero
			// Comprueba si la distancia es 1 o menos
			if (this.distanciaUnitaria(this.jugador, atacado)) {
				atacado.vitalidad = Math.max(0, atacado.vitalidad - this.jugador.potencia);
			}
			else {
				armadura = IAvatar.MAXIMO - atacado.potencia;
				atacado.vitalidad = Math.max(0, atacado.vitalidad - Math.max(0, this.jugador.potencia - armadura)); 
			}
			
			// Comprueba si hemos matado al avatar
			if (atacado.vitalidad == 0) {
				// La posiciÃ³n del campo de batalla ya no tiene un avatar
				campoBatalla[atacado.pos.abscisa()][atacado.pos.ordenada()] = avatarNulo;
				mutex_tablero[pos.abscisa()][pos.ordenada()].release();

				// Un avatar vivo menos y un avatar muerto mÃ¡s
				try {
					mutex_vivos.acquire();
				} catch (InterruptedException e) {
					// Error no recuperable
					System.err.println("Cliente " + this.id_Cliente + ": No se ha podido adquirir la lista de jugadores vivos en exclusiva");
					System.exit(-1);
				}
				avataresVivos.remove(atacado);
				mutex_vivos.release();
				try {
					mutex_muertos.acquire();
				} catch (InterruptedException e) {
					// Error no recuperable
					System.err.println("Cliente " + this.id_Cliente + ": No se ha podido adquirir la lista de jugadores muertos en exclusiva");
					System.exit(-1);
				}
				avataresMuertos.add(atacado);
				mutex_muertos.release();
			}
			else {
				mutex_tablero[pos.abscisa()][pos.ordenada()].release();
			}
			
			return true;
		}
		
		mutex_tablero[pos.abscisa()][pos.ordenada()].release();
		
		// Ataque NO certero
		return false;
	}

	@Override
	public boolean juegoFinalizado() {
		boolean fin;
		
		// No puede haber finalizado si todavÃ­a no empezÃ³
		if (this.estado < 0) return false;
		
		// HabrÃ¡ finalizado si solo quedÃ³ uno vivo
		try {
			mutex_vivos.acquire();
		} catch (InterruptedException e) {
			// Error no recuperable
			System.err.println("Cliente " + this.id_Cliente + ": No se ha podido adquirir la lista de jugadores vivos en exclusiva");
			System.exit(-1);
		}
		fin = avataresVivos.size() == 1;
		mutex_vivos.release();
		
		return fin;		
	}

	private boolean desbordamiento(Coordenadas pos) {
		return pos.abscisa() < 0 || pos.ordenada() < 0 ||
			   pos.abscisa() >= DIMENSION || pos.ordenada() >= DIMENSION;
	}
	
	private void moverAvatar(Coordenadas new_pos) throws MovimientoNoValido, PosicionOcupada {
		// Comprobar si hay desbordamiento
		if (this.desbordamiento(new_pos)) throw new MovimientoNoValido("No puedes realizar ese movimiento, te saldrÃ­as del campo de batalla.");
		
		// Comprobar si hay colisiÃ³n
		try {
			mutex_tablero[new_pos.abscisa()][new_pos.ordenada()].acquire();
		} catch (InterruptedException e) {
			// Error no recuperable
			System.err.println("Cliente " + this.id_Cliente + ": No se ha podido adquirir el tablero en exclusiva");
			System.exit(-1);
		}
		if (campoBatalla[new_pos.abscisa()][new_pos.ordenada()] != avatarNulo) {			
			Avatar av = campoBatalla[new_pos.abscisa()][new_pos.ordenada()];
			mutex_tablero[new_pos.abscisa()][new_pos.ordenada()].release();
			throw new PosicionOcupada(String.format("No puedes moverse a esa posiciÃ³n, Â¡ya estÃ¡ el avatar %s!", av.alias));			
		}
		
		// Tiempo que tarda en moverse
		try {
			Thread.sleep(IAvatar.INICIAR_DESPLAZAMIENTO);
		} catch (InterruptedException e1) {
			// Error recuperable
			System.err.println("Cliente " + this.id_Cliente + ": No se ha podido aplicar retraso en el desplazamiento al avatar");			
		}
		
		// Modificar el campo de batalla
		campoBatalla[new_pos.abscisa()][new_pos.ordenada()] = this.jugador;
		mutex_tablero[new_pos.abscisa()][new_pos.ordenada()].release();
		try {
			mutex_tablero[this.jugador.pos.abscisa()][this.jugador.pos.ordenada()].acquire();
		} catch (InterruptedException e) {
			// Error no recuperable
			System.err.println("Cliente " + this.id_Cliente + ": No se ha podido adquirir el tablero en exclusiva");
			System.exit(-1);
		}
		campoBatalla[this.jugador.pos.abscisa()][this.jugador.pos.ordenada()] = avatarNulo;
		mutex_tablero[this.jugador.pos.abscisa()][this.jugador.pos.ordenada()].release();
		
		// Asignar la nueva posiciÃ³n a la posiciÃ³n actual
		this.jugador.pos = new_pos;				
	}

	private boolean distanciaUnitaria(Avatar atacante, Avatar atacado) {
		if (atacante.pos.ordenada() == atacado.pos.ordenada()) {
			return Math.abs(atacante.pos.abscisa() - atacado.pos.abscisa()) <= 1;
		}
		if (atacante.pos.abscisa() == atacado.pos.abscisa()) {
			return Math.abs(atacante.pos.ordenada() - atacado.pos.ordenada()) <= 1;
		}
		
		return false;
	}
	
	
	
	//////EJERCICIO 1 DESCONEXIÓN PARTIDA
	
	@Override
	public void close() {
		IAvatar.super.close();

		if(!juegoFinalizado()) {
			try {
				mutex_conectados.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			jugadoresConectados--;
			mutex_conectados.release();
			try {
				mutex_unidos.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			jugadoresUnidos--;
			mutex_unidos.release();

			if (estado==100) {

				try {
					mutex_muertos.acquire();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				AvatarOOS.avataresMuertos.remove(jugador);
				mutex_muertos.release();
			}
			else {
				try {
					mutex_vivos.acquire();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				AvatarOOS.avataresVivos.remove(jugador);
				mutex_vivos.release();
				
				try {
					mutex_tablero[jugador.pos.abscisa()][jugador.pos.ordenada()].acquire();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				campoBatalla[jugador.pos.abscisa()][jugador.pos.ordenada()]=avatarNulo;
				mutex_tablero[jugador.pos.abscisa()][jugador.pos.ordenada()].release();
			}
		}else {
			try {
				mutex_vivos.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			AvatarOOS.avataresVivos.clear();;
			mutex_vivos.release();

			try {
				mutex_muertos.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			AvatarOOS.avataresMuertos.clear();
			mutex_muertos.release();

			try {
				mutex_conectados.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			jugadoresConectados=0;
			mutex_conectados.release();

			try {
				mutex_unidos.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			jugadoresUnidos=0;
			mutex_unidos.release();
			
			for(int i=0;i<DIMENSION;i++) {
				for(int j=0;j<DIMENSION;j++) {
					try {
						mutex_tablero[i][j].acquire();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					campoBatalla[i][j]=avatarNulo;
					mutex_tablero[i][j].release();
				}
			}
			
			
		}
	}
	
	
	/////EJERCICIO2
	public void teletransporte() throws TeletransporteNoValido{
		
		// Comprueba que pueda teletransportarse
				if (this.estado < 0 || this.estado == 100) {
					return;
				}
				
				// Comprobar si el avatar ha sido asesinado
				if (this.jugador.vitalidad == 0) {
					// Acaban de matar a este avatar. Pasamos al estado 100 y salimos
					this.estado = 100;
					return;
				}
				
				if(this.jugador.teletransportes<=0) {
					throw new TeletransporteNoValido();
				}else {
					this.jugador.teletransportes--;
					int fila;
					int columna;
					boolean fin;
					Random r = new Random();
					do {
						fila= r.nextInt(DIMENSION);
						columna=r.nextInt(DIMENSION);
						
						try {
							mutex_tablero[fila][columna].acquire();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						
						fin=campoBatalla[fila][columna]!=avatarNulo;
						mutex_tablero[fila][columna].release();
						
					}while(fin);
					
					try {
						mutex_tablero[fila][columna].acquire();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					campoBatalla[fila][columna]=this.jugador;
					mutex_tablero[fila][columna].release();
					
					this.jugador.pos=new Coordenadas(fila,columna);
				
				}
		
	}
	
	//EJERCICIO 3
	public List<String> aliasJugadoresVivos(){
		if (this.estado < 0 || this.estado == 100) {
			return null;
		}
		
		// Comprobar si el avatar ha sido asesinado
		if (this.jugador.vitalidad == 0) {
			// Acaban de matar a este avatar. Pasamos al estado 100 y salimos
			this.estado = 100;
			return null;
		}
		
		List<String> alias = new LinkedList<String>();
		
		try {
			mutex_vivos.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<Avatar> avataresV= new LinkedList<Avatar>(AvatarOOS.avataresVivos);
		
		mutex_vivos.release();
		
		for(Avatar a: avataresV ) {
			alias.add(a.alias);
		}
		
		return alias;
	}
	


}
