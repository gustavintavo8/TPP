package numismatik.adapter.solution.class_version;

public class Test {

	public static void main(String[] args) {
		// Ejemplo de uso
		Numismatik app = new Numismatik();
		EuroCoin c = new EuroCoin("spanish 5cents coin", 2015, "Spain", 0.05);
		
		// Generate the stamp direct
		StampAdapter s = new StampAdapter("Vader", 2017, "Spain", 5.00); // Changing Stamp -> StampAdapter
		
		System.out.println("Adding a coin to the collection...");
		app.addToCollection( c ); // add c to collection
		
		System.out.println("Adding a stamp to the collection...");
		app.addToCollection( s );  // add s to collection
		
		app.showCollection();
	}
}
