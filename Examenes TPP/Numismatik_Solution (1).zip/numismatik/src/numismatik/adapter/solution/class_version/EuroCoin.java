package numismatik.adapter.solution.class_version;

public class EuroCoin implements Item{
	private String description;
	private int year;
    private String country;
    private double value;


    public EuroCoin(String description, int year, String country, double d) {
    	this.description = description;
        this.year = year; this.country = country; this.value = d;
    }
    // getters 
    public int getYear() { return year; }
    public String getCountry() { return country; }
    public double getValue() { return value; }
	public String getDescription() { return description; }
	@Override
	public String toString() {
		return String.format("EuroCoin [description=%s, year=%s, country=%s, value=%s]", description, year, country,
				value);
	}

}
