package numismatik.adapter.solution.class_version;

public class StampAdapter extends Stamp implements Item{
	

    public StampAdapter(String id, int productionDate, 
			String region, double cost) {
    	super(id, productionDate, region, cost);
    }
    
    // getters 
    @Override
    public int getYear() { return this.getProductionDate(); }
    @Override
    public String getCountry() { return this.getRegion(); }
    @Override
    public double getValue() { return this.getCost(); }
    @Override
	public String getDescription() { return this.getId(); }
    
    @Override
	public String toString() { return this.toString(); }
    
}
