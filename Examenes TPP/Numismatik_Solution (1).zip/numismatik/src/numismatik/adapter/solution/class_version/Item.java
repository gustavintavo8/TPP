package numismatik.adapter.solution.class_version;

public interface Item {
    int getYear();
    String getCountry();
    double getValue();
	String getDescription();
}
