package numismatik.adapter.solution.class_version;

import java.util.ArrayList;

public class Numismatik {
	//...
	private ArrayList<Item> myCollection; // Changing EuroCoin -> Item
	
	public Numismatik() {
		myCollection = new ArrayList<Item>();
	}
	
	// add coin to the collection
	public void addToCollection(Item c) { // Changing EuroCoin -> Item
		myCollection.add(c);
	}
	
	public void showCollection() {
		System.out.println("Collection:");
		System.out.println(myCollection);
		
	}
}
