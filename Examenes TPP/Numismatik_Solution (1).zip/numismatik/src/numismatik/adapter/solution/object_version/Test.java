package numismatik.adapter.solution.object_version;

public class Test {

	public static void main(String[] args) {
		// Ejemplo de uso
		Numismatik app = new Numismatik();
		EuroCoin c = new EuroCoin("spanish 5cents coin", 2015, "Spain", 0.05);
		Stamp s = new Stamp("Vader", 2017, "Spain", 5.00);
		
		System.out.println("Adding a coin to the collection...");
		app.addToCollection( c ); // add c to collection
		
		System.out.println("Adding a stamp to the collection...");
		app.addToCollection( new StampAdapter(s) );  // add s to collection
		
		app.showCollection();
	}
}
