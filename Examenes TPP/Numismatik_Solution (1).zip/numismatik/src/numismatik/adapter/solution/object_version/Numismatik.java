package numismatik.adapter.solution.object_version;

import java.util.ArrayList;

public class Numismatik {
	//...
	private ArrayList<EuroCoin> myCollection;
	
	public Numismatik() {
		myCollection = new ArrayList<EuroCoin>();
	}
	
	// add coin to the collection
	public void addToCollection(EuroCoin c) {
		myCollection.add(c);
	}
	
	public void showCollection() {
		System.out.println("Collection:");
		System.out.println(myCollection);
		
	}
}
