package numismatik.adapter.solution.object_version;

public class StampAdapter  extends EuroCoin{
	private Stamp _stamp;

    public StampAdapter(Stamp _stamp) {
    	super("", 0, "", 0); // we will ignore the internal fields of EuroCoin
    	this._stamp = _stamp;
    }
    // getters 
    @Override
    public int getYear() { return _stamp.getProductionDate(); }
    @Override
    public String getCountry() { return _stamp.getRegion(); }
    @Override
    public double getValue() { return _stamp.getCost(); }
    @Override
	public String getDescription() { return _stamp.getId(); }
    
    @Override
	public String toString() { return _stamp.toString(); }
    
}
