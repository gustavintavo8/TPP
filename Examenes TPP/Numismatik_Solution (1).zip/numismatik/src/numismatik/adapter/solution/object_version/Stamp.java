package numismatik.adapter.solution.object_version;

public class Stamp {
	private String id;
	private int productionDate;
	private String region;
	private double cost;

	public Stamp(String id, int productionDate, 
			String region, double cost) {
		this.id = id; 
		this.productionDate = productionDate; this.region = region; 			
		this.cost = cost;
	}
	// getters 
	public String getId() { return id; }
	public int getProductionDate() { return productionDate; }
	public String getRegion() { return region; }
	public double getCost() { return cost; }
	@Override
	public String toString() {
		return String.format("Stamp [id=%s, productionDate=%s, region=%s, cost=%s]", id, productionDate, region, cost);
	}
	
}

