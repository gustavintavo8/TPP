package numismatik.adapter.initial;

public class Stamp {
	private String description;
	private int year;
	private String country;
	private double value;

	public Stamp(String description, int year, 
			String country, double value) {
		this.description = description; this.year = year;
		this.country = country; this.value = value;
	}
	// getters 
	public String getDescription() { return description; }
	public int getYear() { return year; }
	public String getCountry() { return country; }
	public double getValue() { return value; }
	@Override
	public String toString() {
		return String.format("Stamp [description=%s, year=%s, country=%s, value=%s]", description, year, country,
				value);
	}
}
