package numismatik.adapter.initial;

public class Test {

	public static void main(String[] args) {
		// Ejemplo de uso
		Numismatik app = new Numismatik();
		EuroCoin c = new EuroCoin("spanish 5cents coin", 2015, "Spain", 0.05);
		Stamp s = new Stamp("Vader", 2017, "Spain", 5.00);
		
		System.out.println("Adding a coin to the collection...");
		app.addToCollection( c ); // add c to collection

		// How can I add stamps in a similar way to adding coins?
		// Something similar to: 
		System.out.println("Adding a stamp to the collection...");		
		System.out.println("I want something similar to: app.addToCollection( s );  // add s to collection");

		app.showCollection();
	
	}
}
