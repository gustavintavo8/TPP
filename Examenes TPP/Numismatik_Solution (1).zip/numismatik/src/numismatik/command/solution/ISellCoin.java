package numismatik.command.solution;

public class ISellCoin implements ICommand {

	private EuroCoin coin;
	private AuctionHouse h;
	
	/**
	 * @param coin the coin
	 * @param h the auction house
	 */
	public ISellCoin(EuroCoin coin, AuctionHouse h) {
		super();
		this.coin = coin;
		this.h = h;
	}

	@Override
	public void execute() {
		h.sellCoin(coin);
	}
}
