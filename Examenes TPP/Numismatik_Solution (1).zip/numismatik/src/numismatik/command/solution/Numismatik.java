package numismatik.command.solution;

import java.util.ArrayList;

public class Numismatik {
	AuctionHouse ah; // auction house manager
	ArrayList<ICommand> operations; // List of add/remove coin operations
	
	public Numismatik() {
		ah = new AuctionHouse(); 
		operations = new ArrayList<ICommand>();
	}
	
	void sellCoin(EuroCoin coin) {
		// add sell coin operation
		operations.add(new ISellCoin(coin, ah));
	}
	
	void buyCoin(EuroCoin coin) {
		// add buy a coin operation
		operations.add(new IBuyCoin(coin, ah));
	}

	void launchOperations() {
		// launch buy/sell operations
		for(ICommand c: operations)
			c.execute();
	}
}
