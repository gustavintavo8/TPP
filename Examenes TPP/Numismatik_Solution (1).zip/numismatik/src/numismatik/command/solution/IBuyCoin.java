package numismatik.command.solution;

public class IBuyCoin implements ICommand {

	private EuroCoin coin;
	private AuctionHouse h;
	
	/**
	 * @param coin the coin
	 * @param h the auction house
	 */
	public IBuyCoin(EuroCoin coin, AuctionHouse h) {
		super();
		this.coin = coin;
		this.h = h;
	}

	@Override
	public void execute() {
		h.buyCoin(coin);
	}

}
