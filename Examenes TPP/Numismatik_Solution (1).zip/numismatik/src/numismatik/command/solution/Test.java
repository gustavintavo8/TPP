package numismatik.command.solution;

public class Test {

	public static void main(String[] args) {
		// Ejemplo de uso
		Numismatik app = new Numismatik();
		EuroCoin c1 = new EuroCoin("Spanish 5 cents coin", 2015, "Spain", 0.05);
		EuroCoin c2 = new EuroCoin("French 1 euro coin", 2021, "Portugal", 0.05);
		
		// selling coin c1
		System.out.println("(Monday) Selling coin c1");
		app.sellCoin(c1);

		System.out.println("\nTime goes by....tic tac tic tac...\n");		
		// Wednesday 
		// buying coin c2
		System.out.println("(Wednesday) Buying coin c2");
		app.buyCoin(c2);
		
		System.out.println("\nTime goes by....tic tac tic tac...\n");
		
		// at the end of the week
		System.out.println("End of the week: launch operations!");
		app.launchOperations();
	}
}
