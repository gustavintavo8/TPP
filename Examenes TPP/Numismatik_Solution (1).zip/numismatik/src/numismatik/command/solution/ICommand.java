package numismatik.command.solution;

public interface ICommand {
	
	void execute();

}
