package numismatik.command.initial;

public class Numismatik {
	AuctionHouse ah; // auction house manager

	public Numismatik() {
		ah = new AuctionHouse(); 
	}

	public void sellCoin(EuroCoin coin) {
		// sell a coin in the Cloud Auction House
		ah.sellCoin(coin);
	}

	public void buyCoin(EuroCoin coin) {
		// buy a coin in the Cloud Auction House
		ah.buyCoin(coin);
	}
}
