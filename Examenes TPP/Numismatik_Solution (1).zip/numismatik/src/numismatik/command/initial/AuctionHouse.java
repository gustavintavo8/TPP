package numismatik.command.initial;

public class AuctionHouse {

	/** 
	 * buy a coin in the Cloud auction house
	 * @param coin the coin
	 */
	public void buyCoin(EuroCoin coin) {
		System.out.println("AH: buying " + coin);
	}

	/**
	 * sell a coin from the Cloud auction house
	 * @param coin
	 */
	public void sellCoin(EuroCoin coin) { 
		System.out.println("AH: selling " + coin);
	}
}
