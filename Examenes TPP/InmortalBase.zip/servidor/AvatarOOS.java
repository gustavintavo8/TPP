package servidor;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import comun.AliasDuplicado;
import comun.Coordenadas;
import comun.IAvatar;
import comun.JuegoIniciado;
import comun.MovimientoNoValido;
import comun.PosicionOcupada;
import comun.PotenciaNoValida;
import optional.Trace;

public class AvatarOOS implements IAvatar {
	// 1. Información Compartida

	// datos (Singletons)
	private static Avatar[][] campoBatalla = null;
	private static Map<Integer, Avatar> avataresVivos;
	private static List<Avatar> avataresMuertos;
	private static Integer jugadoresUnidos;
	private static Integer jugadoresConectados;

	private static class Avatar {
		static Avatar avatarNulo() {
			return new Avatar();
		}

		// información del avatar
		String alias;
		int vitalidad;
		int potencia;
		// posición en el campo de batalla
		int fila;
		int columna;
		// propietario del avatar
		int idCliente;
		// objeto de exclusión mutua del avatar para información que
		// no tenga que ver con su posición (p.e., vitalidad, potencia, etc.)
		boolean isNull = false;

		private Avatar() {
			isNull = true;
		}

		Avatar(int idCliente, String alias, int potencia) {
			this.alias = alias;
			this.vitalidad = VITALIDAD_INICIAL;
			this.potencia = potencia;
			this.idCliente = idCliente;
			// posicionamiento al azar en un espacio
			// libre del campo de batalla (con avatar nulo)
			Random r = new Random();
			do {
				this.fila = r.nextInt(DIMENSION);
				this.columna = r.nextInt(DIMENSION);
			} while (!campoBatalla[this.fila][this.columna].isNull);
			campoBatalla[fila][columna] = this;
		}
	}

	// 2. Información Exclusiva

	private int estado; // id de estado
	private int idCliente;
	private static Object initMonitor = new Object();

	public AvatarOOS(int idCliente) {
		this.estado = -10; // estado inicial, antes de unirse al juego
		this.idCliente = idCliente;

		synchronized (initMonitor) {
			if (campoBatalla == null) { // iniciar datos compartidos
				jugadoresUnidos = 0;
				jugadoresConectados = 0;
				// campo de batalla inicial
				campoBatalla = new Avatar[DIMENSION][DIMENSION];

				for (int i = 0; i < DIMENSION; i++) {
					for (int j = 0; j < DIMENSION; j++) {
						campoBatalla[i][j] = Avatar.avatarNulo();

					}
				}

				avataresVivos = new TreeMap<>();
				avataresMuertos = new LinkedList<>();
			}
		}
	}

	private boolean aliasExistente(String alias) {

		synchronized (avataresVivos) {
			for (Avatar avatar : avataresVivos.values()) {
				if (avatar.alias.contentEquals(alias)) {
					return true;
				}
			}
		}

		return false;
	}

	@Override
	public void unirse(String alias, int potencia) throws JuegoIniciado, AliasDuplicado, PotenciaNoValida {
		if (this.estado != -10) {
			// usuario ya unido al juego
			return;
		}

		synchronized (jugadoresUnidos) {
			if (jugadoresUnidos == NUMERO_JUGADORES) { // ¡sección crítica!
				throw new JuegoIniciado("No te puedes unir, el juego ya ha comenzado\n");
			}
		}

		if (aliasExistente(alias)) {
			throw new AliasDuplicado(String.format("El alias %s ya existe\n", alias));
		}
		if (potencia >= MAXIMO) {
			throw new PotenciaNoValida(String.format("Rango de potencias: [1, %d]\n", MAXIMO - 1));
		}

		// crear el avatar (¡sección crítica!)
		synchronized (jugadoresUnidos) {
			Avatar avatar = new Avatar(this.idCliente, alias, potencia);
			avataresVivos.put(this.idCliente, avatar);
			jugadoresUnidos++;
			jugadoresConectados++;
		}
		this.estado = -1; // el usuario se ha unido al juego

		Trace.printf(this.idCliente, "Estado: %d, Jugadores: %d\n", this.estado, jugadoresUnidos);

	}

	public boolean comenzar() {
		if (this.estado != -1) {
			// juego ya iniciado o avatar muerto
			return false;
		}
		// ¡sección crítica!
		synchronized (jugadoresUnidos) {
			if (jugadoresUnidos == NUMERO_JUGADORES) {
				this.estado = 0;
			}
		}

		Trace.printf(this.idCliente, "Estado: %d, Jugadores: %d\n", this.estado, jugadoresUnidos);

		return this.estado == 0;
	}

	private void comprobarValidez(int n) throws MovimientoNoValido {
		if (n < 0 || n >= DIMENSION) {
			throw new MovimientoNoValido("Tablero desbordado\n");
		}
	}

	@Override
	public void moverX(boolean b) throws MovimientoNoValido, PosicionOcupada {
		if (this.estado < 0 || this.estado == 100) {
			// usuario no unido, juego no iniciado o avatar muerto
			return;
		}

		if (vida() == 0) { // actualiza la vida del avatar
			return;
		}

		if (this.estado != 3) {
			Avatar avatar = avataresVivos.get(idCliente);
			int delta = b ? 1 : -1;
			comprobarValidez(avatar.fila + delta);

			try {
				Thread.sleep(INICIAR_DESPLAZAMIENTO);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			// ¡sección crítica!
			synchronized (campoBatalla[avatar.fila + delta][avatar.columna]) {
				if (!campoBatalla[avatar.fila + delta][avatar.columna].isNull) {
					throw new PosicionOcupada(); // enemigo encontrado
				}
				synchronized (campoBatalla[avatar.fila][avatar.columna]) {
					campoBatalla[avatar.fila][avatar.columna] = Avatar.avatarNulo();
					avatar.fila += delta;
					campoBatalla[avatar.fila][avatar.columna] = avatar;
				}
			}
			this.estado = this.estado == 1 ? 3 : 1;

			Trace.printf(this.idCliente, "Estado: %d\n", this.estado);

		}
	}

	@Override
	public void moverY(boolean b) throws MovimientoNoValido, PosicionOcupada {
		if (this.estado < 0 || this.estado == 100) {
			// usuario no unido, juego no iniciado o avatar muerto
			return;
		}

		if (vida() == 0) { // actualiza la vida del avatar
			return;
		}

		if (this.estado != 4) {
			Avatar avatar = avataresVivos.get(idCliente);
			int delta = b ? 1 : -1;
			comprobarValidez(avatar.columna + delta);
			// ¡sección crítica!
			synchronized (campoBatalla[avatar.fila][avatar.columna + delta]) {
				if (!campoBatalla[avatar.fila][avatar.columna + delta].isNull) {
					throw new PosicionOcupada(); // enemigo encontrado
				}
			}
			try {
				Thread.sleep(INICIAR_DESPLAZAMIENTO);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			// ¡sección crítica!
			synchronized (campoBatalla[avatar.fila][avatar.columna + delta]) {
				if (!campoBatalla[avatar.fila][avatar.columna + delta].isNull) {
					throw new PosicionOcupada(); // enemigo encontrado
				}
				synchronized (campoBatalla[avatar.fila][avatar.columna]) {
					campoBatalla[avatar.fila][avatar.columna] = Avatar.avatarNulo();
					avatar.columna += delta;
					campoBatalla[avatar.fila][avatar.columna] = avatar;
				}
			}
			this.estado = this.estado == 2 ? 4 : 2;

			Trace.printf(this.idCliente, "Estado: %d\n", this.estado);

		}
	}

	@Override
	public void mover2X(boolean b) throws MovimientoNoValido, PosicionOcupada {
		if (this.estado < 0 || this.estado == 100) {
			// usuario no unido, juego no iniciado o avatar muerto
			return;
		}

		if (vida() == 0) { // actualiza la vida del avatar
			return;
		}

		if (this.estado == 2 || this.estado == 4) {
			Avatar avatar = avataresVivos.get(idCliente);
			int delta = b ? 2 : -2;
			comprobarValidez(avatar.fila + delta);
			// ¡sección crítica!
			synchronized (campoBatalla[avatar.fila + delta][avatar.columna]) {
				if (!campoBatalla[avatar.fila + delta][avatar.columna].isNull) {
					throw new PosicionOcupada(); // enemigo encontrado
				}
			}
			try {
				Thread.sleep(INICIAR_DESPLAZAMIENTO);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			// ¡sección crítica!
			synchronized (campoBatalla[avatar.fila + delta][avatar.columna]) {
				if (!campoBatalla[avatar.fila + delta][avatar.columna].isNull) {
					throw new PosicionOcupada(); // enemigo encontrado
				}
				synchronized (campoBatalla[avatar.fila][avatar.columna]) {
					campoBatalla[avatar.fila][avatar.columna] = Avatar.avatarNulo();
					avatar.fila += delta;
					campoBatalla[avatar.fila][avatar.columna] = avatar;
				}
			}
			this.estado = 3;

			Trace.printf(this.idCliente, "Estado: %d\n", this.estado);

		}
	}

	@Override
	public void mover2Y(boolean b) throws MovimientoNoValido, PosicionOcupada {
		if (this.estado < 0 || this.estado == 100) {
			// usuario no unido, juego no iniciado o avatar muerto
			return;
		}

		if (vida() == 0) { // actualiza la vida del avatar
			return;
		}

		if (this.estado == 1 || this.estado == 3) {
			Avatar avatar = avataresVivos.get(idCliente);
			int delta = b ? 2 : -2;
			comprobarValidez(avatar.columna + delta);
			// ¡sección crítica!
			synchronized (campoBatalla[avatar.fila][avatar.columna + delta]) {
				if (!campoBatalla[avatar.fila][avatar.columna + delta].isNull) {
					throw new PosicionOcupada(); // enemigo encontrado
				}
			}
			try {
				Thread.sleep(INICIAR_DESPLAZAMIENTO);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			// ¡sección crítica!
			synchronized (campoBatalla[avatar.fila][avatar.columna + delta]) {
				if (!campoBatalla[avatar.fila][avatar.columna + delta].isNull) {
					throw new PosicionOcupada(); // enemigo encontrado
				}
				synchronized (campoBatalla[avatar.fila][avatar.columna]) {
					campoBatalla[avatar.fila][avatar.columna] = Avatar.avatarNulo();
					avatar.columna += delta;
					campoBatalla[avatar.fila][avatar.columna] = avatar;
				}
			}
			this.estado = 4;

			Trace.printf(this.idCliente, "Estado: %d\n", this.estado);

		}
	}

	@Override
	public Coordenadas posicion() {
		if (this.estado == -10 || this.estado == 100) {
			// usuario no unido o avatar muerto
			return null;
		}

		if (vida() == 0) { // actualiza la vida del avatar
			return null;
		}

		Avatar avatar = avataresVivos.get(idCliente);
		return new Coordenadas(avatar.fila, avatar.columna);
	}

	@Override
	public int vida() {
		if (this.estado == -10 || this.estado == 100) {
			// usuario no unido o avatar muerto
			return 0;
		}

		Avatar avatar;
		synchronized (avataresVivos) {
			avatar = avataresVivos.get(idCliente);
		}

		if (avatar == null) { // avatar muerto
			this.estado = 100;
			return 0;
		} else {
			synchronized (campoBatalla[avatar.fila][avatar.columna]) {
				if (avatar.vitalidad == 0) {
					this.estado = 100;
				}
			}
		}

		return avatar.vitalidad;
	}

	@Override
	public void setPotencia(int potencia) throws PotenciaNoValida {
		if (this.estado < 0 || this.estado == 100) {
			// usuario no unido, juego no iniciado o avatar muerto
			return;
		}

		if (vida() == 0) { // actualiza la vida del avatar
			return;
		}

		if (potencia >= MAXIMO) {
			throw new PotenciaNoValida(String.format("Rango de potencias: [1, %d]\n", MAXIMO - 1));
		}
		Avatar avatar;
		boolean cambiado = false;
		synchronized (avataresVivos) {
			avatar = avataresVivos.get(idCliente);
		}
		if (avatar == null)
			return;

		synchronized (campoBatalla[avatar.fila][avatar.columna]) {
			if (potencia > avatar.potencia) {
				cambiado = true;
				avatar.potencia = potencia;
			}
		}
		try {
			Thread.sleep(PENALIZACION);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if (!cambiado) {
			synchronized (campoBatalla[avatar.fila][avatar.columna]) {
				avatar.potencia = potencia;
			}
		}
	}

	private boolean distanciaUnitaria(Avatar atacante, Avatar atacado) {
		if (atacante.fila == atacado.fila) {
			return Math.abs(atacante.columna - atacado.columna) <= 1;
		}
		if (atacante.columna == atacado.columna) {
			return Math.abs(atacante.fila - atacado.fila) <= 1;
		}

		return false;
	}

	@Override
	public boolean atacar(int fila, int columna) {
		if (this.estado < 0 || this.estado == 100) {
			// usuario no unido, juego no iniciado o avatar muerto
			return false;
		}

		if (vida() == 0) { // actualiza la vida del avatar
			return false;
		}

		if (fila < 0 || fila > DIMENSION || columna < 0 || columna > DIMENSION) {
			// ataque fuera del campo de batalla
			return false;
		}

		Avatar avatar;
		synchronized (avataresVivos) {
			avatar = avataresVivos.get(idCliente);
		}

		Avatar atacado;
		boolean ataqueCertero = false;
		boolean muerto = false;
		// ¡sección crítica!
		synchronized (campoBatalla[fila][columna]) {
			atacado = campoBatalla[fila][columna];
			ataqueCertero = !atacado.isNull;
			if (ataqueCertero) {
				int potencia;
				potencia = avatar.potencia;

				if (distanciaUnitaria(avatar, atacado)) {
					atacado.vitalidad -= potencia;
				} else {
					atacado.vitalidad -= Math.max(0, potencia - (MAXIMO - atacado.potencia));
				}

				if (atacado.vitalidad <= 0) { // muerte del avatar atacado
					campoBatalla[fila][columna] = Avatar.avatarNulo();
					atacado.vitalidad = 0;
					muerto = true;

				}
			}
		}

		if ( muerto) {
			// actualizar las listas de avatares
			synchronized (avataresVivos) {
				avataresVivos.remove(atacado.idCliente);
			}
			synchronized (avataresMuertos) {
				avataresMuertos.add(atacado);
			}
		}

		return ataqueCertero;
	}

	@Override
	public boolean juegoFinalizado() {
		if (this.estado < 0) {
			return false;
		}
		// ¡sección crítica!
		int avataresConVida;
		synchronized (avataresVivos) {
			avataresConVida = avataresVivos.size();
		}
		return avataresConVida <= 1;
	}

}
