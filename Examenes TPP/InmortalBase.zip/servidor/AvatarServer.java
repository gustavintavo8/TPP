package servidor;

import java.io.IOException;

import lib.ChannelException;
import lib.CommServer;
import optional.Trace;

public class AvatarServer {
	private static void registrarOperaciones(CommServer com) {
		com.addAction("unirse", 
				(o, x) -> ((AvatarOOS)o).unirse((String)x[0], (int) x[1]));
		com.addFunction("comenzar",
				(o, x) -> ((AvatarOOS)o).comenzar());
		com.addAction("moverX",
				(o, x) -> ((AvatarOOS)o).moverX((boolean)x[0]));
		com.addAction("moverY",
				(o, x) -> ((AvatarOOS)o).moverY((boolean)x[0]));
		com.addAction("mover2X",
				(o, x) -> ((AvatarOOS)o).mover2X((boolean)x[0]));
		com.addAction("mover2Y",
				(o, x) -> ((AvatarOOS)o).mover2Y((boolean)x[0]));
		com.addFunction("posicion",
				(o, x) -> ((AvatarOOS)o).posicion());
		com.addFunction("atacar",
				(o, x) -> ((AvatarOOS)o).atacar((int)x[0], (int)x[1]));
		com.addFunction("vida",
				(o, x) -> ((AvatarOOS)o).vida());
		com.addAction("setPotencia",
				(o, x) -> ((AvatarOOS)o).setPotencia((int)x[0]));		
		com.addFunction("juegoFinalizado",
				(o, x) -> ((AvatarOOS)o).juegoFinalizado());
	}
	
	public static void main(String[] args) {
		CommServer com;	// canal de comunicación del servidor
		int idCliente;	// identificador del cliente
		
		try {
			// crear el canal de comunicación del servidor
			com = new CommServer();
			
			// activar la traza en el servidor (opcional)
			Trace.activateTrace(com);
			
			// activar el registro de mensajes del servidor (opcional)
			com.activateMessageLog();
			
			// registrar operaciones del servicio
			registrarOperaciones(com);
								
			// ofrecer el servicio (queda a la escucha)
			while (true) {
				// espera por un cliente
				idCliente = com.waitForClient();			
				
				// conversación con el cliente en un hilo
				Trace.printf("-- Creando hilo para el cliente %d.\n",
						idCliente);
				new Thread(new HilosAvatar(idCliente, com)).start();
				Trace.printf("-- Creado hilo para el cliente %d.\n",
						idCliente);
			}
		} catch (IOException | ChannelException e) {
			System.err.printf("Error: %s\n", e.getMessage());
			e.printStackTrace();
		}
	}

}
