package comun;

public class MovimientoNoValido extends Exception {
	private static final long serialVersionUID = -2993019501292356458L;

	public MovimientoNoValido() {
		super();
	}

	public MovimientoNoValido(String mensaje_error) {
		super(mensaje_error);
	}
}
