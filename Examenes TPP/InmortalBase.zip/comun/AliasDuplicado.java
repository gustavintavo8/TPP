package comun;

public class AliasDuplicado extends Exception {
	private static final long serialVersionUID = -2993019501292356458L;

	public AliasDuplicado() {
		super();
	}

	public AliasDuplicado(String mensaje_error) {
		super(mensaje_error);
	}
}
