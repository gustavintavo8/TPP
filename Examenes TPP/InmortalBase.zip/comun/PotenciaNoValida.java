package comun;

public class PotenciaNoValida extends Exception {
	private static final long serialVersionUID = -2993019501292356458L;

	public PotenciaNoValida() {
		super();
	}

	public PotenciaNoValida(String mensaje_error) {
		super(mensaje_error);
	}
}
