package comun;

import java.io.Serializable;

public class Coordenadas implements Serializable {
	private static final long serialVersionUID = -8734066714412480929L;
	private int x;
	private int y;
	
	public Coordenadas(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public int abscisa() {
		return x;
	}
	
	public int ordenada() {
		return y;
	}
	
	@Override
	public String toString() {
		return String.format("(%d, %d)", x, y);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof Coordenadas))
			return false;
		Coordenadas other = (Coordenadas) obj;
		if (x != other.x)
			return false;
		if (y != other.y)
			return false;
		return true;
	}	

}
