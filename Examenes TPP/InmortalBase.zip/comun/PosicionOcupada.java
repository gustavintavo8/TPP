package comun;

public class PosicionOcupada extends Exception {
	private static final long serialVersionUID = -2993019501292356458L;

	public PosicionOcupada() {
		super();
	}

	public PosicionOcupada(String mensaje_error) {
		super(mensaje_error);
	}
}
