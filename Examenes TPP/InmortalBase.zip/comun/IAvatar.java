package comun;

public interface IAvatar extends lib.DefaultService {

	// constantes configurables
	static final int NUMERO_JUGADORES = 3;
	static final int DIMENSION = 8;
	static final int VITALIDAD_INICIAL = 15;
	static final int MAXIMO = 10;
	static final int INICIAR_DESPLAZAMIENTO = 300;	// en milisegundos
	static final int PENALIZACION = 1500;  			// en milisegundos
	
	void unirse(String alias, int potencia)
			throws JuegoIniciado, AliasDuplicado, PotenciaNoValida;
	
	boolean comenzar();
	
	void moverX(boolean b)
			throws MovimientoNoValido, PosicionOcupada;
	
	void moverY(boolean  b)
			throws MovimientoNoValido, PosicionOcupada;
	
	void mover2X(boolean b)
			throws MovimientoNoValido, PosicionOcupada;
	
	void mover2Y(boolean b)
			throws MovimientoNoValido, PosicionOcupada;
	
	Coordenadas posicion();
	
	int vida();
	
	void setPotencia(int potencia) throws PotenciaNoValida;
	
	boolean atacar(int fila, int columna);
	
	boolean juegoFinalizado();
}
