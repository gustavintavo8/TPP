package cliente;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;

import comun.AliasDuplicado;
import comun.Coordenadas;
import comun.IAvatar;
import comun.JuegoIniciado;
import comun.MovimientoNoValido;
import comun.PosicionOcupada;
import comun.PotenciaNoValida;
import lib.ChannelException;
import lib.CommClient;
import lib.Menu;
import lib.ProtocolMessages;
import lib.UnknownOperation;

/**
 * Ejemplo de programa cliente.
 */
public class AvatarCliente {

	/**
	 * Canal de comunicación del cliente. La comunicación con el
	 * servidor se establece al crear este objeto. 
	 */
	private static CommClient com;	// canal de comunicación del cliente
	
	/**
	 * Menú textual de lanzamiento de eventos.
	 */
	private static Menu m;				// interfaz

	private static void mover(boolean cambiarFila)
			throws IOException, ChannelException {
		Menu menuIncr = new Menu("\nDesplazamiento", "Opción ? ", false);
		
		menuIncr.add("[-2]", -2);
		menuIncr.add("[-1]", -1);
		menuIncr.add("[+1]", +1);
		menuIncr.add("[+2]", +2);
		
		int incr = menuIncr.getInteger();  // cantidad a desplazar
		String idEvento;
		if (cambiarFila) {
			idEvento = Math.abs(incr) == 1 ? "moverX" : "mover2X";
		} else {
			idEvento = Math.abs(incr) == 1 ? "moverY" : "mover2Y";
		}
		
		// crear mensaje a enviar
		ProtocolMessages peticion = new ProtocolMessages(idEvento, incr > 0);
		// enviar mensaje
		com.sendEvent(peticion);
		// esperar por la respuesta
		ProtocolMessages respuesta;
		try {
			respuesta = com.waitReply();
			// procesar respuesta o excepción
			com.processReply(respuesta);	
		} catch (ClassNotFoundException | UnknownOperation e) {
			System.err.printf("Recibido del servidor: %s\n", e.getMessage());
		} catch (MovimientoNoValido e) {
			System.err.printf("MovimientoNoValido: %s\n", e.getMessage());
		} catch (PosicionOcupada e) {
			System.err.printf("PosicionOcupada: %s\n", e.getMessage());
		} catch (Exception e) {
			System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
					e.getMessage());
		}
	}
	
	private static Coordenadas obtenerPosicion()
			throws IOException, ChannelException {
		Coordenadas coord = null;
		// crear mensaje a enviar
		ProtocolMessages peticion = new ProtocolMessages("posicion");
		// enviar mensaje
		com.sendEvent(peticion);
		try {
			// esperar por la respuesta
			ProtocolMessages respuesta = com.waitReply();
			// procesar respuesta o excepción
			coord = (Coordenadas)com.processReply(respuesta);
		} catch (ClassNotFoundException | UnknownOperation e) {
			System.err.printf("Recibido del servidor: %s\n", e.getMessage());
		} catch (Exception e) {
			System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
					e.getMessage());
		}

		return coord;
	}
	
	private static void modPotencia()
			throws IOException, ChannelException {
		// obtener valor de la nueva potencia
		System.out.print("Valor de la potencia: ");
		boolean OK = false;
		int n = 0;
		while (!OK) {
			try {
				System.out.print(String.format("Potencia [1, %d]\n",
						IAvatar.MAXIMO - 1));
				n = m.input().nextInt();
				OK = true;
			} catch (InputMismatchException e) {
				System.err.println("Error al propocionar la potencia");
				m.input().nextLine();
			}
		}
		// crear mensaje a enviar
		ProtocolMessages peticion = new ProtocolMessages("setPotencia", n);
		// enviar mensaje
		com.sendEvent(peticion);
		try {
			// esperar por la respuesta
			ProtocolMessages respuesta = com.waitReply();
			// procesar respuesta o excepción
			com.processReply(respuesta);	
		} catch (ClassNotFoundException | UnknownOperation e) {
			System.err.printf("Recibido del servidor: %s\n", e.getMessage());
		} catch (PotenciaNoValida e) {
			System.err.printf("PotenciaNoValida: %s\n", e.getMessage());
		} catch (Exception e) {
			System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
					e.getMessage());
		}
	}

	private static void atacar()
			throws IOException, ChannelException {
		// obtener coordenadas de ataque
		boolean OK = false;
		int fila = 0;
		int columna = 0;
		while (!OK) {
			try {
				System.out.print("Fila? ");
				fila = m.input().nextInt();
				System.out.print("Columna? ");
				columna = m.input().nextInt();
				OK = true;
			} catch (InputMismatchException e) {
				System.err.println("Error al propocionar las coordenadas");
				m.input().nextLine();
			}
		}
		// crear mensaje a enviar
		ProtocolMessages peticion = new ProtocolMessages("atacar", fila, columna);
		// enviar mensaje
		com.sendEvent(peticion);
		try {
			// esperar por la respuesta
			ProtocolMessages respuesta = com.waitReply();
			// procesar respuesta o excepción
			boolean diana = (boolean)com.processReply(respuesta);
			if (diana) {
				System.out.println("\nHas dado en el blanco.");
			} else {
				System.out.println("\nHas fallado.");
			}
		} catch (ClassNotFoundException | UnknownOperation e) {
			System.err.printf("Recibido del servidor: %s\n", e.getMessage());
		} catch (Exception e) {
			System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
					e.getMessage());
		}
	}
	
	/**
	 * Crea la interfaz de lanzamiento de eventos. Un menú textual
	 * en el que cada opción tiene asociada una función que lanza
	 * un evento (con los argumentos que éste requiera).
	 * 
	 * <p>El comportamiento del cliente podría verse afectado por 
	 * los efectos del evento o por la posible respuesta de éste.
	 * En este caso, simplemente se mostrarán en consola los
	 * resultados o excepciones que se produzcan.</p> 
	 */
	private static void interfazCliente() {
		m = new Menu("\nAvatar", "Opción ? ");
		
		m.add("Cambiar de fila", () -> mover(true));		
		m.add("Cambiar de columna", () -> mover(false));
		m.add("Atacar una posición (fila, columna)", () -> atacar());
		m.add("Modificar la potencia", () -> modPotencia());
		
	} // interfazCliente
	
	private static void unirseAlJuego() throws Exception {
		String alias = null;
		int potencia = 0;
		
		try {
			// solicitar alias y potencia para unirse al juego
			System.out.print("Alias del avatar: ");
			alias = m.input().next(); 
			System.out.printf("Potencia del avatar [1, %d]: ",
					IAvatar.MAXIMO - 1);
			potencia = m.input().nextInt();
			ProtocolMessages request = new ProtocolMessages("unirse",
					alias, potencia);
			com.sendEvent(request);
			ProtocolMessages response = com.waitReply();
			com.processReply(response);
		} catch (InputMismatchException e) {
			System.err.println("Error al introducir los datos requeridos\n");
			unirseAlJuego();
		} catch (NoSuchElementException e) {
			System.err.println("Error al introducir los datos requeridos\n");
			unirseAlJuego();
		} catch (ClassNotFoundException e) {
			System.err.println("Error en la respuesta del servidor");
			unirseAlJuego();			
		} catch (AliasDuplicado e) {
			System.err.printf("El alias %s ya está utilizado por otro jugador\n",
					alias);
			unirseAlJuego();
		} catch (PotenciaNoValida e) {
			System.err.printf("La potencia dada %d no es válida\n",
					potencia);
			unirseAlJuego();
		}
	}

	private static boolean inicioDelJuego() throws Exception {
		boolean OK = false;
		try {
			ProtocolMessages request = new ProtocolMessages("comenzar");
			com.sendEvent(request);
			ProtocolMessages response = com.waitReply();
			OK = (boolean)com.processReply(response);
		} catch (ClassNotFoundException e) {
			inicioDelJuego();
		}
		
		return OK;
	}
	
	private static boolean finDelJuego() throws Exception {
		boolean OK = false;
		try {
			ProtocolMessages request = new ProtocolMessages("juegoFinalizado");
			com.sendEvent(request);
			ProtocolMessages response = com.waitReply();
			OK = (boolean)com.processReply(response);
		} catch (ClassNotFoundException e) {
			finDelJuego();
		}
		
		return OK;
	}

	private static int vidaDelAvatar() throws Exception {
		int vida = 0;
		try {
			ProtocolMessages request = new ProtocolMessages("vida");
			com.sendEvent(request);
			ProtocolMessages response = com.waitReply();
			vida = (int)com.processReply(response);
		} catch (ClassNotFoundException e) {
			vidaDelAvatar();
		}
		
		return vida;
	}
	
	public static void main(String[] args) {
		int vida = 0;
		
		try {
			// establecer la comunicación con el servidor
			// crear el canal de comunicación y establecer la
			// conexión con el servicio por defecto en localhost
			com = new CommClient();
			
			// activa el registro de mensajes del cliente
			com.activateMessageLog();  // opcional			
		} catch (UnknownHostException e) {
			System.err.printf("Servidor desconocido. %s\n", e.getMessage());
			System.exit(-1);	// salida con error
		} catch (IOException | ChannelException e) {
			System.err.printf("Error: %s\n", e.getMessage());
			System.exit(-1);	// salida con error
		}
		
		// crear la interfaz del juego
		interfazCliente();
		
		try {
			// unirse al juego
			unirseAlJuego();
		} catch (JuegoIniciado e) {
			System.err.printf("JuegoIniciado: %s\n", e.getMessage());
			System.exit(0);		// salida sin error
		} catch (Exception e) {
			System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
					e.getMessage());
			System.exit(-1);	// salida con error
		}
		
		try {
			System.out.println("Esperando al resto de jugadores...");
 			while (!inicioDelJuego()) {
 				// esperar por los jugadores requeridos
 				Thread.sleep(1000);
 			}
 			System.out.println("\n!Comienza el juego!");
			System.out.printf("Dimensión del campo de batalla: %d x %d\n",
					IAvatar.DIMENSION, IAvatar.DIMENSION);
			
			// lanzar eventos mediante la interfaz
 			boolean cerrarCliente = false;
 			boolean juegoTerminado = false;
			do {
				vida = vidaDelAvatar();
				if (vida == 0) {
					System.out.println("\n¡Tu avatar ha muerto!");
				} else {
					System.out.printf("\nVida del avatar: %d\n", vida);
					System.out.printf("Avatar en %s\n", obtenerPosicion());
					cerrarCliente = !m.runSelection();
				}
				juegoTerminado = finDelJuego();
			} while (!cerrarCliente && !juegoTerminado && vida > 0);
			
			if (!cerrarCliente) {
				while (!juegoTerminado) {
	 				// esperar a que el juego termine
	 				Thread.sleep(5000);
	 				// mostrar más información si es necesario
					juegoTerminado = finDelJuego(); 
				}
				System.out.println("\n¡El juego ha finalizado!");
			}
		} catch (IOException | ChannelException e) {
			System.err.printf("Error crítico: %s\n", e.getMessage());
		} catch (Exception e) {
			System.err.printf("%s: %s", e.getClass().getSimpleName(),
					e.getMessage());
			e.printStackTrace();
		} finally {
			// cierra la interfaz si es necesario
			m.close();
			// cierra el canal de comunicación y
			// desconecta el cliente
			com.disconnect();
		}
		
	} // main

} // class AvatarCliente
