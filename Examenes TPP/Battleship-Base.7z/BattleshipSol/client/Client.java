package client;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import common.UnallowedAction;
import common.IncorrectlyPlacedShip;
import common.InvalidCoordinates;
import common.Battleship;
import common.InvalidShipSize;
import lib.ChannelException;
import lib.CommClient;
import lib.Menu;
import lib.ProtocolMessages;
import lib.UnknownOperation;

public class Client {

	/**
	 * Clilent's communication channel. The communication with the
	 * server is established when this object is created.
	 */
	private static CommClient com;	// client's communication channel

	/**
	 * Scanner to ask for coordinates.
	 */
	private static Scanner scanner = new Scanner(System.in);


	private static int numShips()
			throws IOException, ChannelException {
		int n = 0;
		// create message to be sent
		ProtocolMessages request = new ProtocolMessages("numShipsOnOcean");
		// send message
		com.sendEvent(request);
		try {
			// wait for the response
			ProtocolMessages response = com.waitReply();
			// process response or exception
			n = (int)com.processReply(response);
		} catch (ClassNotFoundException | UnknownOperation e) {
			System.err.printf("Received from server: %s\n", e.getMessage());
		} catch (IOException | ChannelException e) {
			throw e;
		} catch (Exception e) {
			System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
					e.getMessage());
		}

		return n;
	}

	private static void showGrid(String id)
			throws IOException, ChannelException {
		// create message to be sent
		ProtocolMessages request = new ProtocolMessages(id);
		// send message
		com.sendEvent(request);
		try {
			// wait for the response
			ProtocolMessages response = com.waitReply();
			// process response or exception
			System.out.println(com.processReply(response));
		} catch (ClassNotFoundException | UnknownOperation e) {
			System.err.printf("Received from server: %s\n", e.getMessage());
		} catch (UnallowedAction | InvalidCoordinates e) {
			System.err.printf("Error: %s\n", e.getMessage());
		} catch (IOException | ChannelException e) {
			throw e;
		} catch (Exception e) {
			System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
					e.getMessage());
		}
	}

	private static void shoot()
			throws IOException, ChannelException {
		// ask for the coordinates of the shot
		System.out.print("Coordinates of the shot? ");
		// create message to be sent
		ProtocolMessages request =
				new ProtocolMessages("shotCoordinates", scanner.nextLine());
		// send message
		com.sendEvent(request);
		try {
			// wait for the response
			ProtocolMessages response = com.waitReply();
			// process response or exception
			System.out.println(com.processReply(response));
		} catch (ClassNotFoundException | UnknownOperation e) {
			System.err.printf("Received from server: %s\n", e.getMessage());
		} catch (IOException | ChannelException e) {
			throw e;
		} catch (Exception e) {
			System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
					e.getMessage());
		}
	}

	private static int myTurn()
		throws IOException, ChannelException {
		int n = 0;
		// create message to be sent
		ProtocolMessages request = new ProtocolMessages("turn");
		// send message
		com.sendEvent(request);
		try {
			// wait for the response
			ProtocolMessages response = com.waitReply();
			// process response or exception
			n = (int)com.processReply(response);
		} catch (ClassNotFoundException | UnknownOperation e) {
			System.err.printf("Received from server: %s\n", e.getMessage());
		} catch (UnallowedAction e) {
			System.err.printf("Action not allowed: %s\n", e.getMessage());
		} catch (IOException | ChannelException e) {
			throw e;
		} catch (Exception e) {
			System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
					e.getMessage());
		}

		return n;
	}

	private static boolean startingGame()
			throws IOException, ChannelException  {
		boolean start = false;
		// create message to be sent
		ProtocolMessages request = new ProtocolMessages("startGame");
		// send message
		com.sendEvent(request);
		try {
			// wait for the response
			ProtocolMessages response = com.waitReply();
			// process response or exception
			start = (boolean) com.processReply(response);
		} catch (ClassNotFoundException | UnknownOperation e) {
			System.err.printf("Received from server: %s\n", e.getMessage());
		} catch (UnallowedAction e) {
			System.err.printf("Action not allowed: %s\n", e.getMessage());
		} catch (IOException | ChannelException e) {
			throw e;
		} catch (Exception e) {
			System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
					e.getMessage());
		}

		return start;
	}

	@SuppressWarnings("unchecked")
	private static Set<Integer> shipsToPlace()
			throws IOException, ChannelException {
		Set<Integer> sizes = new TreeSet<>();
		// create message to be sent
		ProtocolMessages request = new ProtocolMessages("shipsToBePlaced");
		// send message
		com.sendEvent(request);
		try {
			// wait for the response
			ProtocolMessages response = com.waitReply();
			// process response or exception
			List<Integer> left = (List<Integer>) com.processReply(response);
			left.forEach(n -> sizes.add(n));
		} catch (ClassNotFoundException | UnknownOperation e) {
			System.err.printf("Received from server: %s\n", e.getMessage());
		} catch (UnallowedAction e) {
			System.err.printf("Action not allowed: %s\n", e.getMessage());
		} catch (IOException | ChannelException e) {
			throw e;
		} catch (Exception e) {
			System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
					e.getMessage());
		}

		return sizes;
	}

	private static void placeShips()
			throws IOException, ChannelException {
		// ask for the sizes of the pending ships to be places
		// on the ocean
		Set<Integer> ships = shipsToPlace();
		int size;
		while (!ships.isEmpty()) { // there are still some ships left
			// shows the ocean
			showGrid("oceanGrid");

			// presents a menu with the sizes of the pending ships
			Menu sizes = new Menu("\nSizes of the ships", "Option? ", false);
			if (ships.size() > 1) {
				ships.forEach(n -> sizes.add(String.format("Ship of size %d", n), n));
			    size = sizes.getInteger();
			} else { // only one size left (but more than one ship might be left)
				size = ships.iterator().next();
			}
			// ask for the coordinates of the edges of the ship
			System.out.printf("Coordinates of the edges of the ship with size %d? ", size);
			// create message to be sent
			ProtocolMessages request = new ProtocolMessages("placeShip",
					sizes.input().nextLine());
			// send message
			com.sendEvent(request);
			try {
				// wait for the response
				ProtocolMessages response = com.waitReply();
				// process response or exception
				com.processReply(response);
			} catch (ClassNotFoundException | UnknownOperation e) {
				System.err.printf("Received from server: %s\n", e.getMessage());
			} catch (InvalidCoordinates | IncorrectlyPlacedShip | InvalidShipSize e) {
				System.err.printf("Error: %s\n", e.getMessage());
			} catch (UnallowedAction e) {
				System.err.printf("Action not allowed: %s\n", e.getMessage());
			} catch (Exception e) {
				System.err.printf("%s: %s\n", e.getClass().getSimpleName(),
						e.getMessage());
			} finally {
				ships = shipsToPlace();
			}
		}

		// shows the ocean
		showGrid("oceanGrid");
	}

	public static void main(String[] args) {

		try {
			// Establish the communication with the server
			// create the communication channel and establish the
			// connection with the service in localhost by default
			com = new CommClient();
			// activate the client's messages register
			com.activateMessageLog();  // optional
		} catch (UnknownHostException e) {
			System.err.printf("Unknown server. %s\n", e.getMessage());
			System.exit(-1);	// exits with an error
		} catch (IOException | ChannelException e) {
			System.err.printf("Error: %s\n", e.getMessage());
			System.exit(-1);	// exits with an error
		}

		try {
			// place the ships on the ocean
			placeShips();

			// if it is possible (opponent available), start the game
			while (!startingGame()) {
				System.out.println("Waiting for an opponent");
				Thread.sleep(5000);
			}

			// launch events through the interface
			int n = myTurn();
			while (n != Battleship.GAME_END) {

				while (n == 0) { // wait for the turn
					// show the ocean
					showGrid("oceanGrid");
					Thread.sleep(3000);
					n = myTurn();
					// show the ocean
					showGrid("oceanGrid");
					Thread.sleep(500);
				}

				while (n == 1) { // your turn 
					// show the shots grid
					showGrid("shotsGrid");				
					// shoot at the opponent's ocean
					shoot();
					// show the shots grid
					showGrid("shotsGrid");
					Thread.sleep(500);
					n = myTurn();
				}

			}

			// show the ocean
			showGrid("shotsGrid");

			if (n != Battleship.GAME_END) { // we resign the game
				System.out.printf("\nYou have resigned!\n");
			} else { // the game is finished
				System.out.printf("\nGame ended: %s\n",
						numShips() == 0 ? "you lost!" : "you won!");
			}
		} catch (IOException | ChannelException e) {
			System.err.printf("Error: %s\n", e.getMessage());
		} catch (Exception e) { // exception of the service
			System.err.printf("Error: %s\n", e.getMessage());
		} finally {
			// close the entry
			scanner.close();
			// close the communication channel and
			// disconnect the client
			com.disconnect();
		}

	} // main

}
