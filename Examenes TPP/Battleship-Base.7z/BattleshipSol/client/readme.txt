In the client program, a slight modification has been made. We have removed the menu for launching events because there were only two options, from which only one was interesting: 
the option of shooting at the opponent's ocean. The other option was the number of ships
on the ocean, which is not relevant until the end of the game.

Now, instead of the Menu, a Scanner is declared, which will be used to read the coordinates.
Since we removed the menu, we also removed clientInterface() and it is necessary to modify
the loop for launching events (turn and shot), which is now clearer.
