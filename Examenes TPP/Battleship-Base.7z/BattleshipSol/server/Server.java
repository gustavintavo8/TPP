package server;

import java.io.IOException;

import lib.ChannelException;
import lib.CommServer;
import optional.Trace;

class Server {
	private static void registerOperations(CommServer com) {
		com.addFunction("oceanGrid",
				(o, x) -> ((Service)o).oceanGrid());
		com.addFunction("shotsGrid",
				(o, x) -> ((Service)o).shotsGrid());
		com.addFunction("shipsToBePlaced",
				(o, x) -> ((Service)o).shipsToBePlaced());
		com.addAction("placeShip",
				(o, x) -> ((Service)o).placeShip((String) x[0]));
		com.addFunction("startGame",
				(o, x) -> ((Service)o).startGame());
		com.addFunction("turn",
				(o, x) -> ((Service)o).turn());
		com.addFunction("shotCoordinates",
				(o, x) -> ((Service)o).shotCoordinates((String) x[0]));
		com.addFunction("numShipsOnOcean",
				(o, x) -> ((Service)o).numShipsOnOcean());
	}

	public static void main(String[] args) {
		CommServer com;	// server's communication channel
		int idClient;	// client's identifier
		
		try {
			// creates the server's communication channel
			com = new CommServer();
			
			// activates the trace in the server (optional)
			Trace.activateTrace(com);
			
			// activates the server's messages register (optional)
			com.activateMessageLog();
			
			// register the service operations
			registerOperations(com);
								
			// offer the service (will be waiting infinitely)
			while (true) {
				// waits for a client
				idClient = com.waitForClient();			
				
				// conversation with the client in a thread
				Trace.printf("-- Creating thread for the client %d.\n",
						idClient);
				new Thread(new MyThreads(idClient, com)).start();
				Trace.printf("-- Thread for the client created %d.\n",
						idClient);
			}
		} catch (IOException | ChannelException e) {
			System.err.printf("Error: %s\n", e.getMessage());
			e.printStackTrace();
		}
	}

}
