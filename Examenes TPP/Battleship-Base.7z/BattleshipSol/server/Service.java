package server;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import common.UnallowedAction;
import common.IncorrectlyPlacedShip;
import common.InvalidCoordinates;
import common.Battleship;
import common.InvalidShipSize;

public class Service implements Battleship {
	private final static String PATTERN_COORD = "^(\\p{Alpha}\\d{1,2}\\s*){2}$";

	// Common information for every OOS

	// players connected to the service and waiting to play
	// (the player must have arranged their ships)
	private volatile static List<Integer> playersWaiting = new LinkedList<>();
	// grids with the arrangements of the ships of each player
	// (the client's identifier is used as a key)
	private volatile static Map<Integer, Grid> playersOcean = new HashMap<>();
	// opponents playing (key and value, client's identifier)
	private volatile static Map<Integer, Integer> opponent = new HashMap<>();
	// to indicate if it is the player's turn (false by default)
	private volatile static Map<Integer, Boolean> playerTurn = new HashMap<>();
	// number of ships not sunk on each player's ocean
	private volatile static Map<Integer, Integer> shipsOnOcean = new HashMap<>();
	// object for the mutual exclusion when starting the game
	private volatile static Object mutex = new Object();
	// objects for the mutual exclusions when switching turn between a pair of players
	private volatile static Map<Integer, Object> mutexTurn = new HashMap<>();

	// Exclusive information for each OOS
	private int idClient;						// identifier
	private List<Integer> shipsLeft;	    	// sizes of the ships left to be placed on the grid
	private Grid ocean;							// own grid with the ships
	private Grid shots;							// opponent's grid, initially blank
	private int state;							// state of the game

	public Service(int idClient) {
		this.idClient = idClient;
		this.shipsLeft = new LinkedList<>(SHIPS);
		this.ocean = new Grid();
		this.shots = new Grid();
		synchronized (playersOcean) {
			playersOcean.put(idClient, this.ocean);			
		}
		synchronized (playerTurn) {
			playerTurn.put(idClient, false);			
		}
		synchronized (shipsOnOcean) {
			shipsOnOcean.put(idClient, 0);
		}
		this.state = 0;  // the player can start placing ships
	}

	@Override
	public String oceanGrid() {
		return this.ocean.toString();
	}

	@Override
	public String shotsGrid() {
		return this.shots.toString();
	}

	@Override
	public List<Integer> shipsToBePlaced() throws UnallowedAction {
		if (this.state != 0) {
			throw new UnallowedAction("shipsToBePlaced");
		}

		if (this.shipsLeft.isEmpty()) { // change the state
			this.state = 1;
		}

		return this.shipsLeft;
	}

	/**
	 * Returns the coordinates provided by the given string.
	 * @param str representation as a string of characters of the coordinates
	 * @return the coordinates
	 * @throws InvalidCoordinates if the format of the string in not correct
	 * or the given position is outside the grid
	 */
	private Pair<Integer, Integer> position(String str)
			throws InvalidCoordinates {

		if (str == null || str.isEmpty() || !str.matches("^\\p{Alpha}\\d{1,2}$")) {
			throw new InvalidCoordinates(
					"Coordinates pattern: ^\\p{Alpha}\\d{1,2}$");
		}

		int row = str.toUpperCase().charAt(0) - (int)'A';
		int col = str.charAt(1) - (int)'0';

		if (str.length() > 2) {
			col = col * 10 + str.charAt(2) - (int)'0';
		}

		if (row < 0 || row >= Battleship.DIMENSION ||
				col < 0 || col >= Battleship.DIMENSION) {
			throw new InvalidCoordinates("Out of the grid");
		}

		return new Pair<>(row, col);
	}

	@Override
	public void placeShip(String str)
			throws InvalidCoordinates, IncorrectlyPlacedShip, InvalidShipSize, UnallowedAction {
		if (this.state != 0) {
			throw new UnallowedAction("placeShip");
		}

		// check that the coordinates are valid
		if (str == null || str.isEmpty() || !str.matches(PATTERN_COORD)) {
			throw new IllegalArgumentException(
					String.format("Coordinates pattern: %s", PATTERN_COORD));
		}

		Pattern pattern = Pattern.compile("\\p{Alpha}\\d{1,2}");
		Matcher matcher = pattern.matcher(
				str.subSequence(0, str.length()));
		matcher.find();
		String str0 = matcher.group();
		matcher.find();
		String str1 = matcher.group();

		// Coordinates of the edges of the ship
		Pair<Integer, Integer> p0 = position(str0);
		Pair<Integer, Integer> p1 = position(str1);

		Integer size = this.ocean.placeShip(p0, p1, this.shipsLeft);

		// a ship of a certain size has been placed
		this.shipsLeft.remove(size);
		shipsOnOcean.put(this.idClient, shipsOnOcean.get(this.idClient) + 1);
	}

	@Override
	public boolean startGame() throws UnallowedAction {
		if (this.state != 1) {
			throw new UnallowedAction("satrtGame");
		}
		synchronized (mutex) {
			if (opponent.get(this.idClient) != null) {
				// the player has an opponent, but not the initial turn
				this.state = 2;
			} else {
				// the player does not have an opponent. We add the player
				// to the queue if possible
				if (playersWaiting.isEmpty()) {
					// wait for an opponent
					playersWaiting.add(this.idClient);
				} else {
					if (playersWaiting.contains(idClient)) {
						if (playersWaiting.size() == 1) {
							// only this client in the queue: keep waiting for an opponent
							return false;
						}

						// a pairing can be made
						playersWaiting.remove((Integer)idClient);
					}

					// once ensured this player is not in the waiting list,
					// the first in the queue is assign as an opponent
					int idOpponent = playersWaiting.remove(0);
					opponent.put(this.idClient, idOpponent);
					opponent.put(idOpponent, this.idClient);
					// objects for the mutual exclusion for switching turns
					// between both players
					mutexTurn.put(this.idClient, new Object());
					mutexTurn.put(idOpponent, mutexTurn.get(this.idClient));
					// the player that allows the pairing to be made
					// has the initial turn
					playerTurn.put(this.idClient, true);
					this.state = 2;
				}
			}
		}

		return this.state == 2;
	}

	@Override
	public int turn() throws UnallowedAction {
		if (this.state < 2) {
			throw new UnallowedAction("turn");
		}

		// ensure that the opponent is still connected
		int idOpponent = opponent.get(this.idClient);
		if (opponent.get(idOpponent) == null) {
			// the opponent has disconnected
			return GAME_END;
		}

		// condition for ending the game
		if (shipsOnOcean.get(this.idClient) == 0 ||
				shipsOnOcean.get(idOpponent) == 0) {
			return GAME_END;
		}

		if (this.state == 2) {
			synchronized (mutexTurn.get(this.idClient)) {
				if (playerTurn.get(this.idClient)) {
					this.state = 3;
				} else { // not the player's turn
					return 0;
				}
			}
		}

		// it is the player's turn
		return 1;
	}

	/**
	 * Changes the state of the player's OOS regarding if their last shot
	 * was a hit or not, and switches turn if necessary.
	 * @param hit {@code true} if the shot hits an opponent's ship
	 */
	private void updateState(boolean hit) {
		if (hit && this.state != 5) { // maintains the turn
			this.state++;
		} else { // switches turn
			this.state = 2;
			synchronized (mutexTurn.get(this.idClient)) {
				playerTurn.put(this.idClient, false);
				playerTurn.put(opponent.get(this.idClient), true);
			}
		}
	}

	@Override
	public void shotCoordinates(String shot){
			
		if (this.state < 2 || this.state == GAME_END) {
			return;
		}
		if (this.state == 2) {
			return;
		}

		// coordinates of the shot
		Pair<Integer, Integer> p = position(shot);
		int row = p.first();
		int col = p.second();

		// shot to the opponent's ocean
		Square square = playersOcean.get(opponent.get(this.idClient)).shot(row, col);

		// register the shot in the shots grid
		if (!square.isShip()) { // miss
			this.shots.table[row][col] = Square.MISS;
			updateState(false);
			if (square == Square.WATER) {
				return;
			}

			if (square == Square.SEPARATOR) {
				return;
			}

			if (square == Square.MISS) {
				return;
			}
		}

		if (square == Ship.HIT) { // ship hit
			this.shots.table[row][col] = square;
			updateState(true);
			return;
		}

		if (square == Ship.SUNK) { // the hit square belonged to an already sunk ship
			updateState(true);
			return;
		}

		// sunk ship, register it on the shots grid
		this.shots.registerShip((Ship)square);
		int idOpponent = opponent.get(this.idClient);
		shipsOnOcean.put(idOpponent, shipsOnOcean.get(idOpponent) - 1);
		updateState(true);
		return;
	}

	@Override
	public int numShipsOnOcean() {
		return shipsOnOcean.get(this.idClient);
	}

	@Override
	public void close() {
		if (this.state < 2) { // disconnection without having started a game
			synchronized (playersWaiting) {
				playersWaiting.remove((Integer)this.idClient);
			}
		}

		int idOpponent = opponent.get(this.idClient);
		if (opponent.get(idOpponent) != null) { // the opponent is still connected
			synchronized (mutexTurn.get(this.idClient)) {
				playerTurn.put(opponent.get(idOpponent), true);
			}
		} else { // the opponent is disconnected
			// delete the shared information of both players
			synchronized (playersOcean) {
				playersOcean.remove(this.idClient);
				playersOcean.remove(idOpponent);				
			}
			synchronized (shipsOnOcean) {
				shipsOnOcean.remove(this.idClient);
				shipsOnOcean.remove(idOpponent);				
			}
			synchronized (playerTurn) {
				playerTurn.remove(this.idClient);
				playerTurn.remove(idOpponent);				
			}
			synchronized (mutexTurn) {
				mutexTurn.remove(this.idClient);
				mutexTurn.remove(idOpponent);
			}
		}

		// this player does not need to know who is the opponent anymore
		opponent.remove(this.idClient);

		Battleship.super.close();
	}

}
