package server;

import java.io.IOException;

import lib.ChannelException;
import lib.CommServer;
import lib.ProtocolMessages;
import optional.Trace;

public class MyThreads implements Runnable {
	private CommServer com;		// server's communication channel
	private int idClient;		// client's ID	
	private Service oos;		// client's OOS

	public MyThreads(int idClient, CommServer com) {
		this.idClient = idClient;
		this.com = com;
	}

	@Override
	public void run() {
		ProtocolMessages request;
		ProtocolMessages response;

		try {
			Trace.print(idClient,
					"-- Creating the service object ... ");
			oos = new Service(idClient);
			Trace.println(idClient, "done.");

			while (!com.closed(idClient)) {
				try {
					// waits for a request from the client
					request = com.waitEvent(idClient);
					// evaluates the received order
					response = com.processEvent(idClient, oos, request);

					if (response != null) { // if it has a response
						// send the response to the client
						com.sendReply(idClient, response);
					}
				} catch (ClassNotFoundException e) {
					System.err.printf("Received from the client %d: %s\n",
							idClient, e.getMessage());
				}				
			}
		} catch (IOException | ChannelException e) {
			System.err.printf("Error: %s\n", e.getMessage());
		} finally {
			// close the OOS
			if (oos != null) {
				oos.close();
			}
		}
	}

}
